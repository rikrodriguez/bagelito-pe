# Bagelito: preview local sobre la imagen exacta

Aplicación: `6f765cee68f4c4d2f013a1082b497a73b5191bd7`.

Requiere Node.js24.19 o compatible. No necesita npm install, DB, cuentas ni credenciales.

1. Descomprimir este ZIP en una carpeta nueva.
2. Abrir una terminal en esa carpeta y ejecutar `node start-review.mjs`.
3. Visitar `http://127.0.0.1:4173/` en el mismo equipo. Para otro puerto: `PORT=4174 node start-review.mjs` (Bash).
4. Ctrl+C detiene el servidor. Borrar la carpeta elimina la preview.

Permite recorrer Packs/Combos/Schmears, revisar selección, upsell opcional, entrega y consentimiento. No cobra, reserva ni crea pedidos; el botón de pago está desactivado. El programa de fidelidad10pedidos→2bagels+1schmear está pendiente de seguimiento interno y canje. Sin Wallet ni integración GHL.

Ambos entrypoints Node fuerzan loopback y el flag que bloquea `/api` antes de los handlers de negocio. La UI se compila en modo revisión. No se despliega ningún servicio. No introducir datos personales reales: los campos sólo permiten revisar la interacción local. La selección desaparece al recargar. TanStack puede leer una clave interna de scroll; no se persiste el pedido.

La imagen es el WebP aprobado sin modificar; no se afirma identidad de bytes con el JPEG. Sus precios dibujados son referencia visual. El flujo conserva el catálogo verificado y deja el importe final pendiente de validación.

`manifest.json` identifica cada archivo y SHA256. `server/review-runtime.mjs` conserva el entrypoint Nitro original byte por byte; `server/index.mjs` es el wrapper de seguridad añadido al artefacto. Este paquete no certifica pagos, stock, fidelidad operativa, Safari o disponibilidad comercial.
