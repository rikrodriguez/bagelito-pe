// node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B5EQxquP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/bagelito-pe/src/routes/__root.tsx",
		children: [
			"/",
			"/legal",
			"/playable",
			"/api/batch",
			"/api/catalog",
			"/api/checkout/quote",
			"/api/checkout/session",
			"/api/webhooks/culqi",
			"/api/payments/culqi/charge",
			"/api/payments/culqi/config",
			"/api/payments/culqi/order",
			"/api/payments/culqi/status"
		],
		css: ["/assets/index-B-tAIt2X.css"],
		preloads: ["/assets/index-aRb2m3Gb.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-aRb2m3Gb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/bagelito-pe/src/routes/index.tsx",
		children: void 0,
		css: ["/assets/ReferenceStorefront-CF3L9wuz.css"],
		preloads: [
			"/assets/routes-BSbH2qWw.js",
			"/assets/ReferenceStorefront-BMQQ7NiK.js",
			"/assets/legal-version-BguVS3S4.js"
		]
	},
	"/legal": {
		filePath: "/workspace/bagelito-pe/src/routes/legal.tsx",
		children: void 0,
		preloads: ["/assets/legal-a6igGOl0.js", "/assets/legal-version-BguVS3S4.js"]
	},
	"/playable": {
		filePath: "/workspace/bagelito-pe/src/routes/playable.tsx",
		children: void 0,
		css: ["/assets/ReferenceStorefront-CF3L9wuz.css"],
		preloads: [
			"/assets/playable-BSbH2qWw.js",
			"/assets/ReferenceStorefront-BMQQ7NiK.js",
			"/assets/legal-version-BguVS3S4.js"
		]
	}
} });
export { tsrStartManifest };
