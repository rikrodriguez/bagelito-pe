// Review-only artifact entrypoint. Always bind to loopback and close APIs.
process.env.BAGELITO_REFERENCE_REVIEW_ONLY = 'true'
process.env.BAGELITO_MERCHANT_REVIEW_ONLY = 'true'
process.env.NITRO_HOST = '127.0.0.1'
process.env.HOST = '127.0.0.1'
const port = Number(process.env.PORT || '4173')
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('PORT must be 1024..65535')
process.env.NITRO_PORT = String(port)
process.env.PORT = String(port)
await import('./review-runtime.mjs')
