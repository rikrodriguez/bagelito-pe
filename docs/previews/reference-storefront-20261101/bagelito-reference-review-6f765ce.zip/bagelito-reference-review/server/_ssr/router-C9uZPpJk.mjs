import { HeadContent, Outlet, Scripts, createFileRoute, createRootRoute, createRouter, lazyRouteComponent, require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { createClient } from "../_libs/supabase__supabase-js.mjs";
import { createHash, randomBytes } from "node:crypto";
// node_modules/.nitro/vite/services/ssr/assets/router-C9uZPpJk.js
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var Route$12 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{
				name: "robots",
				content: "noindex,nofollow"
			},
			{ title: "Bagelito — Vista previa de tienda (sin cobros)" },
			{
				name: "description",
				content: "Vista previa del recorrido de Bagelito. No se aceptan cobros online desde esta versión."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:site_name",
				content: "Bagelito"
			},
			{
				property: "og:title",
				content: "Bagelito | Bagels artesanales en Lima"
			}
		],
		links: []
	}),
	component: RootComponent
});
function RootComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Document, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
function Document({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "es",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
var $$splitComponentImporter$2 = () => import("./routes-C0mOgfVU.mjs");
var Route$11 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./legal-BiX6ymNW.mjs");
var Route$10 = createFileRoute("/legal")({
	head: () => ({ meta: [{ title: "Políticas de compra y delivery | Bagelito.pe" }, {
		name: "description",
		content: "Términos operativos de compra, pago, delivery, privacidad, cancelaciones y reembolsos de Bagelito.pe."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./playable-LQPJThO_.mjs");
var Route$9 = createFileRoute("/playable")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
function isBatchAcceptingOrders(status, ordersCloseAt, now = Date.now(), ordersOpenAt = null) {
	if (status !== "orders_open") return false;
	if (ordersOpenAt) {
		const opensAt = new Date(ordersOpenAt).getTime();
		if (!Number.isFinite(opensAt) || now < opensAt) return false;
	}
	if (!ordersCloseAt) return true;
	const closesAt = new Date(ordersCloseAt).getTime();
	return Number.isFinite(closesAt) && now < closesAt;
}
/**
* Framework-independent, READ-ONLY translation of the batch capacity projection
* in Bagelito Next.js src/lib/reservations/service.ts.
* Never use availability checks alone to accept or commit an order. The order
* reservation RPC enforces the transactional capacity and payment constraints.
*/
function fallbackBatchAvailability(status = "closed") {
	return {
		accepting: false,
		batchName: "Next Bagelito Batch",
		capacityBagels: null,
		capacityPacks: null,
		deliveryDate: null,
		ordersOpenAt: null,
		ordersCloseAt: null,
		remainingBagels: null,
		remainingPacks: null,
		reservedBagels: 0,
		reservedPacks: 0,
		status
	};
}
/** Mirror source semantics: expired pending/failed Culqi holds no longer use space. */
function computeBatchUsage(orders, now = Date.now()) {
	const active = orders.filter((order) => {
		if (order.status === "cancelled") return false;
		return !(order.payment_provider === "culqi" && (order.payment_status === "pending" || order.payment_status === "failed") && !!order.payment_expires_at && new Date(order.payment_expires_at).getTime() <= now);
	});
	return {
		reservedBagels: active.reduce((sum, order) => sum + Number(order.pack_units), 0),
		reservedPacks: active.length
	};
}
/** Read-only projection equivalent to getReservationBatchAvailability for fixtures. */
function projectBatchAvailability(batch, orders, now = Date.now(), nextPackUnits = 6) {
	if (!batch) return fallbackBatchAvailability("closed");
	const usage = computeBatchUsage(orders, now);
	const accepting = isBatchAcceptingOrders(batch.status, batch.orders_close_at, now, batch.orders_open_at) && !(batch.capacity_packs && usage.reservedPacks + 1 > Number(batch.capacity_packs)) && !(batch.capacity_bagels && usage.reservedBagels + nextPackUnits > Number(batch.capacity_bagels));
	return {
		accepting: Boolean(accepting),
		batchName: batch.name,
		capacityBagels: batch.capacity_bagels,
		capacityPacks: batch.capacity_packs,
		deliveryDate: batch.delivery_date,
		ordersOpenAt: batch.orders_open_at,
		ordersCloseAt: batch.orders_close_at,
		remainingBagels: batch.capacity_bagels ? Math.max(0, Number(batch.capacity_bagels) - usage.reservedBagels) : null,
		remainingPacks: batch.capacity_packs ? Math.max(0, Number(batch.capacity_packs) - usage.reservedPacks) : null,
		reservedBagels: usage.reservedBagels,
		reservedPacks: usage.reservedPacks,
		status: batch.status
	};
}
/** Server-only Supabase adapter. Does not create, update or charge anything. */
var currentBatchSelect = "id, name, status, orders_open_at, orders_close_at, delivery_date, capacity_packs, capacity_bagels";
async function getBatchReadOnly(nextPackUnits = 6) {
	const url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
	const secret = process.env.SUPABASE_SERVICE_ROLE_KEY;
	if (!url || !secret) return {
		batch: fallbackBatchAvailability("closed"),
		status: 503
	};
	try {
		const client = createClient(url, secret, { auth: {
			autoRefreshToken: false,
			persistSession: false
		} });
		const { data: current, error: currentError } = await client.from("batches").select(currentBatchSelect).order("created_at", { ascending: false }).limit(1).maybeSingle();
		if (currentError) throw currentError;
		const batch = current;
		if (!batch?.id) return {
			batch: fallbackBatchAvailability("closed"),
			status: 200
		};
		let { data: orders, error: orderError } = await client.from("orders").select("pack_units, status, payment_provider, payment_status, payment_expires_at").eq("batch_id", batch.id).neq("status", "cancelled");
		if (orderError?.code === "42703") {
			const legacy = await client.from("orders").select("pack_units, status").eq("batch_id", batch.id).neq("status", "cancelled");
			orders = legacy.data;
			orderError = legacy.error;
		}
		if (orderError) throw orderError;
		return {
			batch: projectBatchAvailability(batch, orders ?? [], Date.now(), nextPackUnits),
			status: 200
		};
	} catch (error) {
		console.error("[Bagelito batch read] unavailable", error instanceof Error ? error.name : "UnknownError");
		return {
			batch: fallbackBatchAvailability("closed"),
			status: 503
		};
	}
}
/** Read-only batch availability, shape-compatible with the existing Next API. */
var Route$8 = createFileRoute("/api/batch")({ server: { handlers: { GET: async () => {
	const result = await getBatchReadOnly();
	return Response.json(result.batch, {
		status: result.status,
		headers: {
			"Cache-Control": "no-store, max-age=0",
			"CDN-Cache-Control": "no-store"
		}
	});
} } } });
var verified_menu_2026_10_21_default = {
	verified_at: "2026-10-21T04:05:00Z",
	source: "https://www.instagram.com/p/DefDmZwmaLZ/",
	source_date: "2026-10-14",
	coverage: "All six images of current pinned menu visually inspected. Initial 12 profile posts read. Complete historical 34 posts/highlights not certified because cloud browser timed out after menu collection.",
	currency: "PEN",
	bagels: [
		{
			"id": "everything",
			"name": "Everything",
			"premium": false,
			"website_image": "https://bagelito.pe/images/bagel-everything.webp"
		},
		{
			"id": "sesame",
			"name": "Sesame",
			"premium": false,
			"website_image": "https://bagelito.pe/images/bagel-sesame.webp"
		},
		{
			"id": "plain",
			"name": "Plain",
			"premium": false,
			"website_image": "https://bagelito.pe/images/bagel-plain.webp"
		},
		{
			"id": "classic-onion",
			"name": "Classic Onion",
			"premium": false,
			"website_image": "https://bagelito.pe/images/bagel-classic-onion.webp"
		},
		{
			"id": "jalapeno-cheddar",
			"name": "Jalapeño Cheddar",
			"premium": true,
			"website_image": "https://bagelito.pe/images/bagel-jalapeno-cheddar.webp"
		},
		{
			"id": "cheddar",
			"name": "Cheddar",
			"premium": true,
			"website_image": "https://bagelito.pe/images/bagel-cheddar.webp"
		},
		{
			"id": "cinnamon-raisin",
			"name": "Cinnamon Raisin",
			"premium": false,
			"website_image": "https://bagelito.pe/images/bagel-cinnamon-raisin.webp"
		},
		{
			"id": "blueberry",
			"name": "Blueberry",
			"premium": false,
			"website_image": "https://bagelito.pe/images/bagel-blueberry.webp"
		}
	],
	bagel_reference_unit_prices: {
		"regular": 10,
		"premium_seasonal": 12,
		"note": "Published menu reference, not authorization to change pack purchase minimum or pricing logic. Premium inclusion in pack pricing not explicit."
	},
	packs: [
		{
			"id": "six-mixed",
			"quantity": 6,
			"mix": "mixed",
			"price": 60
		},
		{
			"id": "six-single",
			"quantity": 6,
			"mix": "single",
			"price": 50
		},
		{
			"id": "twelve-mixed",
			"quantity": 12,
			"mix": "mixed",
			"price": 115
		},
		{
			"id": "twelve-single",
			"quantity": 12,
			"mix": "single",
			"price": 100
		}
	],
	schmears: [
		{
			"id": "whipped-original",
			"name": "Whipped Original",
			"price_class": "original"
		},
		{
			"id": "aji-amarillo",
			"name": "Ají Amarillo",
			"note": "con cebolla y sal",
			"price_class": "flavoured"
		},
		{
			"id": "herb-roasted-garlic",
			"name": "Herb & Roasted Garlic",
			"price_class": "flavoured"
		},
		{
			"id": "honey-cinnamon",
			"name": "Honey Cinnamon",
			"note": "con miel de Oxapampa",
			"price_class": "flavoured"
		},
		{
			"id": "classic-strawberry",
			"name": "Classic Strawberry",
			"note": "con fresas frescas del mercado",
			"price_class": "flavoured"
		}
	],
	schmear_sizes: [
		{
			"grams": 120,
			"label": "Just a Lil",
			"original_price": 12,
			"flavoured_price": 16
		},
		{
			"grams": 180,
			"label": "Solid Schmear",
			"original_price": 18,
			"flavoured_price": 23
		},
		{
			"grams": 240,
			"label": "Like NYC",
			"original_price": 22,
			"flavoured_price": 29
		}
	],
	combos: [
		{
			"id": "perfect-pair",
			"name": "Perfect Pair",
			"bagels": 6,
			"mix": "mixed",
			"schmear_count": 1,
			"schmear_grams_each": 120,
			"price": 74
		},
		{
			"id": "brunch-pack",
			"name": "Brunch Pack",
			"bagels": 12,
			"mix": "mixed",
			"schmear_count": 2,
			"schmear_grams_each": 120,
			"price": 140
		},
		{
			"id": "schmear-lover",
			"name": "Schmear Lover",
			"bagels": 6,
			"mix": "mixed",
			"schmear_count": 3,
			"schmear_grams_each": 120,
			"price": 99
		}
	],
	combo_upgrades: {
		"published_text": "¿Más schmear en tu pack? 180 g +S/6 | 240 g +S/13",
		"granularity": "NOT explicit whether per pot or combo; do not infer charging logic."
	},
	mini_packs: [
		{
			"quantity": 6,
			"mixed_price": 25,
			"single_price": 20
		},
		{
			"quantity": 12,
			"mixed_price": 40,
			"single_price": 35
		},
		{
			"quantity": 24,
			"mixed_price": 75,
			"single_price": 70
		}
	],
	custom_colors: {
		"minimum_quantity": 6,
		"base_price": 50,
		"one_two_colors_extra": 0,
		"three_five_colors_extra": 10,
		"six_seven_rainbow_colors_extra": 15,
		"website_image": "https://bagelito.pe/images/bagel-rainbow.webp"
	},
	seasonal_observations: [
		{
			"name": "Pumpkin Spice",
			"source": "https://www.instagram.com/bagelito.pe/p/DeMvf3HlTXd/",
			"status": "Pinned October campaign says available until October31, or pumpkin supply lasts. Verify stock before checkout.",
			"ingredients": "roasted pumpkin puree, cinnamon, ginger, nutmeg, cloves, cardamom"
		},
		{
			"name": "Birthday Cake",
			"source": "https://www.instagram.com/bagelito.pe/p/Ddomsw2lbLV/",
			"status": "Birthday promotion for that week's first20orders; not evidence currently offered."
		},
		{
			"name": "Snickerdoodle",
			"source": "https://bagelito.pe",
			"status": "Website seasonal catalog only; not corroborated in current pinned IG menu.",
			"website_image": "https://bagelito.pe/images/bagel-snickerdoodle.webp"
		}
	],
	fulfilment: {
		"profile": "Freshly Baked Every Friday; delivery Lima",
		"menu_slide6": "Friday afternoon deliveries",
		"exception_source": "https://www.instagram.com/bagelito.pe/p/DerpfxzlQW4/",
		"exception": "This week's delivery Thursday October22; following week returns regular Friday schedule."
	},
	conflicts: [
		"Live website states monthly batch and closed orders; current Instagram states weekly Friday production. Do not import website monthly rule as confirmed commercial truth.",
		"Website lists10 flavors including Rainbow/Custom Colors and Snickerdoodle; current IG regular menu has8 plus custom-color service, seasonal launches separately.",
		"Current website has no schmear/combos; Instagram October14 has full published products above."
	]
};
/**
* Bagelito read-only, portable shop-selection contract.
* Published menu evidence: catalog-verified-for-design.md (2026-10-21)
* Product journey approved later: Packs (Grande/Mini), Combos (2 bagels + schmear), Schmears.
* DO NOT charge from this module. All commerce amounts must be server-verified.
*/
var regularFlavorIds = new Set(verified_menu_2026_10_21_default.bagels.map((item) => item.id));
var miniPackSizes = /* @__PURE__ */ new Set([
	6,
	12,
	24
]);
var regularPackSizes = /* @__PURE__ */ new Set([6, 12]);
var priceForRegular = new Map(verified_menu_2026_10_21_default.packs.map((p) => [`${p.quantity}:${p.mix}`, p.price]));
var miniPrice = new Map(verified_menu_2026_10_21_default.mini_packs.flatMap((p) => [[`${p.quantity}:mixed`, p.mixed_price], [`${p.quantity}:single`, p.single_price]]));
function invalid(reason) {
	return {
		status: "invalid",
		publishedBasePen: null,
		checkoutAllowed: false,
		reasons: [reason]
	};
}
function review$1(pricePen, reason) {
	return {
		status: "review_required",
		publishedBasePen: pricePen,
		checkoutAllowed: false,
		reasons: [reason]
	};
}
function ready(pricePen) {
	return {
		status: "ready",
		publishedBasePen: pricePen,
		checkoutAllowed: true,
		reasons: []
	};
}
function validBagelSelection(selection, units, mix) {
	if (!Array.isArray(selection) || selection.length === 0) return "Select at least one bagel flavor.";
	if (!selection.every((s) => s && regularFlavorIds.has(s.flavorId) && Number.isInteger(s.quantity) && s.quantity > 0)) return "Bagel flavors and quantities must match the verified regular menu.";
	if (new Set(selection.map((s) => s.flavorId)).size !== selection.length) return "Duplicate flavor rows are not supported; combine quantities.";
	if (selection.reduce((sum, s) => sum + s.quantity, 0) !== units) return `Select exactly ${units} bagels.`;
	if (mix === "single" && selection.length !== 1) return "Single-flavor packs must contain exactly one flavor.";
	return null;
}
function getVerifiedDisplayMenu() {
	return {
		sourceDate: verified_menu_2026_10_21_default.source_date,
		verifiedAt: verified_menu_2026_10_21_default.verified_at,
		currency: verified_menu_2026_10_21_default.currency,
		bagels: verified_menu_2026_10_21_default.bagels,
		schmears: verified_menu_2026_10_21_default.schmears,
		schmearSizes: verified_menu_2026_10_21_default.schmear_sizes,
		largePacks: verified_menu_2026_10_21_default.packs,
		miniPacks: verified_menu_2026_10_21_default.mini_packs,
		historicalPublishedCombos: verified_menu_2026_10_21_default.combos
	};
}
/** Preview only: this pure function never reserves stock or charges a customer. */
function quotePublishedPack(input) {
	const { format, quantity, mix, selection } = input;
	if (format !== "grande" && format !== "mini") return invalid("Invalid pack format.");
	if (mix !== "mixed" && mix !== "single") return invalid("Invalid mix type.");
	if (!(format === "grande" ? regularPackSizes : miniPackSizes).has(quantity)) return invalid("Unsupported pack quantity for selected format.");
	const bad = validBagelSelection(selection, quantity, mix);
	if (bad) return invalid(bad);
	const price = (format === "grande" ? priceForRegular : miniPrice).get(`${quantity}:${mix}`);
	if (typeof price !== "number") return invalid("No published base price for this format.");
	if (format === "mini") return review$1(price, "Mini flavor availability and compatibility are not confirmed for the selected varieties.");
	if (selection.some((item) => verified_menu_2026_10_21_default.bagels.some((b) => b.id === item.flavorId && b.premium))) return review$1(price, "Published menu does not define premium flavor surcharge or inclusion in packs.");
	return ready(price);
}
/** Only printed individual schmear-pot prices are used for preview. */
function quotePublishedSchmear(input) {
	const flavor = verified_menu_2026_10_21_default.schmears.find((s) => s.id === input.flavorId);
	const size = verified_menu_2026_10_21_default.schmear_sizes.find((s) => s.grams === input.grams);
	if (!flavor || !size) return invalid("Unknown schmear flavor or size.");
	return ready(flavor.price_class === "original" ? size.original_price : size.flavoured_price);
}
/** Read-only menu provenance; not approval to charge current prices. */
var Route$7 = createFileRoute("/api/catalog")({ server: { handlers: { GET: async () => Response.json({
	purpose: "published-reference-only",
	checkoutEnabled: false,
	catalog: getVerifiedDisplayMenu()
}, { headers: { "Cache-Control": "no-store" } }) } } });
function bagelSelection(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return null;
	const rows = Object.entries(value).filter(([, quantity]) => Number(quantity) > 0).map(([flavorId, quantity]) => ({
		flavorId,
		quantity: Number(quantity)
	}));
	if (!rows.every((row) => Number.isInteger(row.quantity) && row.quantity > 0)) return null;
	return rows;
}
function schmearSelection(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return [];
	return Object.entries(value).filter(([, quantity]) => Number(quantity) > 0).map(([flavorId, quantity]) => ({
		flavorId,
		quantity: Number(quantity)
	}));
}
function unavailable(reason, batchAccepting = false) {
	return {
		status: "unavailable",
		checkoutAllowed: false,
		amountPen: null,
		reasons: [reason],
		batchAccepting
	};
}
function review(amountPen, reasons, batchAccepting) {
	return {
		status: "review_required",
		checkoutAllowed: false,
		amountPen,
		reasons,
		batchAccepting
	};
}
async function quoteGuidedOrder(input) {
	const category = input.category;
	const batch = await getBatchReadOnly(category === "packs" && Number.isInteger(Number(input.packQty)) ? Number(input.packQty) : 6);
	if (batch.status !== 200 || !batch.batch.accepting) return unavailable("El batch actual no tiene capacidad para este pedido.");
	if (!batch.batch.deliveryDate) return unavailable("El batch está visible, pero todavía no tiene una fecha de delivery confirmada para cobrar pedidos.");
	const bagels = bagelSelection(input.bagels);
	const schmears = schmearSelection(input.schmears);
	const schmearSize = Number(input.schmearSize);
	if (category === "packs") {
		if (!bagels) return {
			status: "invalid",
			checkoutAllowed: false,
			amountPen: null,
			reasons: ["Selección de bagels inválida."],
			batchAccepting: true
		};
		const format = input.packFormat === "mini" ? "mini" : input.packFormat === "grande" ? "grande" : null;
		const requestedMix = input.packMix === "single" ? "single" : input.packMix === "mixed" ? "mixed" : null;
		const quantity = Number(input.packQty);
		if (!format || !requestedMix || !Number.isInteger(quantity)) return {
			status: "invalid",
			checkoutAllowed: false,
			amountPen: null,
			reasons: ["Configuración de pack inválida."],
			batchAccepting: true
		};
		const pack = quotePublishedPack({
			format,
			quantity,
			mix: bagels.length === 1 ? "single" : "mixed",
			selection: bagels
		});
		if (pack.status !== "ready" || typeof pack.publishedBasePen !== "number") return review(pack.publishedBasePen, pack.reasons, true);
		if (schmears.length === 0) return {
			status: "ready",
			checkoutAllowed: true,
			amountPen: pack.publishedBasePen,
			reasons: [],
			batchAccepting: true
		};
		if (schmears.length !== 1 || schmears[0]?.quantity !== 1) return review(pack.publishedBasePen, ["El pack solo admite un schmear opcional en este journey."], true);
		const schmear = quotePublishedSchmear({
			flavorId: schmears[0].flavorId,
			grams: 120
		});
		if (schmear.status !== "ready" || typeof schmear.publishedBasePen !== "number") return review(pack.publishedBasePen, schmear.reasons, true);
		return review(pack.publishedBasePen + schmear.publishedBasePen, ["El esquema transaccional actual todavía no persiste schmears dentro del pedido; no se cobrará hasta portar esa línea de producto."], true);
	}
	if (category === "schmears") {
		if (schmears.length !== 1 || schmears[0]?.quantity !== 1 || !Number.isInteger(schmearSize)) return {
			status: "invalid",
			checkoutAllowed: false,
			amountPen: null,
			reasons: ["Selecciona un schmear y tamaño válidos."],
			batchAccepting: true
		};
		const schmear = quotePublishedSchmear({
			flavorId: schmears[0].flavorId,
			grams: schmearSize
		});
		if (schmear.status !== "ready" || typeof schmear.publishedBasePen !== "number") return review(schmear.publishedBasePen, schmear.reasons, true);
		if ((bagels?.reduce((sum, row) => sum + row.quantity, 0) ?? 0) > 0) return review(schmear.publishedBasePen, ["El precio del cross-sell de 2 u 8 bagels todavía no está aprobado para cobro automático."], true);
		return review(schmear.publishedBasePen, ["El esquema transaccional actual todavía no soporta pedidos standalone de schmear."], true);
	}
	if (category === "combos") return review(null, ["Los combos del mockup aún usan composición/precio histórico y no están autorizados para cobro automático."], true);
	return {
		status: "invalid",
		checkoutAllowed: false,
		amountPen: null,
		reasons: ["Categoría de pedido inválida."],
		batchAccepting: true
	};
}
function createSupabaseAdminClient() {
	const url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
	const serviceRole = process.env.SUPABASE_SERVICE_ROLE_KEY;
	if (!url || !serviceRole) throw new Error("Missing Supabase server environment variables.");
	return createClient(url, serviceRole, { auth: {
		autoRefreshToken: false,
		persistSession: false
	} });
}
var rules = {
	payments: {
		requester: [
			"payments_requester",
			20,
			600
		],
		contact: [
			"payments_contact",
			10,
			3600
		]
	},
	reservations: {
		requester: [
			"reservations_requester",
			6,
			600
		],
		contact: [
			"reservations_contact",
			4,
			43200
		]
	},
	quotes: { requester: [
		"checkout_quotes_requester",
		40,
		600
	] }
};
var PublicApiError = class extends Error {
	status;
	retryAfterSeconds;
	constructor(message, status = 400, retryAfterSeconds = null) {
		super(message);
		this.status = status;
		this.retryAfterSeconds = retryAfterSeconds;
		this.name = "PublicApiError";
	}
};
function hash(value) {
	return createHash("sha256").update(value).digest("hex");
}
function requesterId(request) {
	const ip = (request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || request.headers.get("cf-connecting-ip") || "").split(",")[0]?.trim();
	if (ip) return "ip:" + ip;
	return "ua:" + (request.headers.get("user-agent") || "unknown").slice(0, 160);
}
function contactId(email, whatsapp) {
	const normalizedEmail = email.trim().toLowerCase();
	if (normalizedEmail) return "email:" + normalizedEmail;
	const digits = whatsapp.replace(/\D/g, "").slice(-9);
	return digits ? "phone:" + digits : "";
}
async function consume(scope, identifier, limit, windowSeconds) {
	let data;
	let error = null;
	try {
		const result = await createSupabaseAdminClient().rpc("consume_api_rate_limit", {
			p_identifier: hash(identifier),
			p_limit: limit,
			p_scope: scope,
			p_window_seconds: windowSeconds
		}).single();
		data = result.data;
		error = result.error;
	} catch {
		throw new PublicApiError("This service is temporarily unavailable.", 503);
	}
	if (error) throw new PublicApiError("This service is temporarily unavailable.", 503);
	const result = data;
	if (!result?.allowed) throw new PublicApiError("Too many attempts. Please try again later.", 429, Math.max(1, Number(result?.retry_after_seconds || windowSeconds)));
}
async function enforcePublicApiSecurity(input) {
	if ((input.trapValue || "").trim()) throw new PublicApiError("Invalid submission.", 400);
	const rule = rules[input.scope];
	const [rScope, rLimit, rWindow] = rule.requester;
	await consume(rScope, requesterId(input.request), rLimit, rWindow);
	const contact = contactId(input.email || "", input.whatsapp || "");
	if (contact && rule.contact) {
		const [cScope, cLimit, cWindow] = rule.contact;
		await consume(cScope, contact, cLimit, cWindow);
	}
}
async function readBoundedJsonObject(request, maxBytes = 16384) {
	const contentType = request.headers.get("content-type") ?? "";
	if (!/^application\/json(?:\s*;|$)/i.test(contentType)) throw new PublicApiError("Invalid JSON request.", 400);
	const declared = request.headers.get("content-length");
	if (declared !== null && (!/^\d+$/.test(declared) || Number(declared) > maxBytes)) throw new PublicApiError("Request body is too large.", 413);
	const reader = request.body?.getReader();
	if (!reader) throw new PublicApiError("Invalid JSON request.", 400);
	const chunks = [];
	let total = 0;
	const deadline = Date.now() + 2e3;
	try {
		for (;;) {
			const remaining = deadline - Date.now();
			if (remaining <= 0) throw new PublicApiError("Request body timed out.", 408);
			let timer;
			const chunk = await Promise.race([reader.read(), new Promise((_, reject) => {
				timer = setTimeout(() => reject(new PublicApiError("Request body timed out.", 408)), remaining);
			})]).finally(() => clearTimeout(timer));
			if (chunk.done) break;
			total += chunk.value.byteLength;
			if (total > maxBytes) throw new PublicApiError("Request body is too large.", 413);
			chunks.push(chunk.value);
		}
	} finally {
		try {
			await reader.cancel();
		} catch {}
		try {
			reader.releaseLock();
		} catch {}
	}
	const merged = new Uint8Array(total);
	let offset = 0;
	for (const chunk of chunks) {
		merged.set(chunk, offset);
		offset += chunk.byteLength;
	}
	let value;
	try {
		value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(merged));
	} catch {
		throw new PublicApiError("Invalid JSON request.", 400);
	}
	if (!value || typeof value !== "object" || Array.isArray(value)) throw new PublicApiError("Invalid JSON request.", 400);
	return value;
}
var Route$6 = createFileRoute("/api/checkout/quote")({ server: { handlers: { POST: async ({ request }) => {
	try {
		await enforcePublicApiSecurity({
			request,
			scope: "quotes"
		});
		const quote = await quoteGuidedOrder(await readBoundedJsonObject(request, 8192));
		return Response.json(quote, {
			status: quote.status === "invalid" ? 400 : quote.status === "unavailable" ? 503 : 200,
			headers: { "Cache-Control": "no-store, max-age=0" }
		});
	} catch (error) {
		const status = error instanceof PublicApiError ? error.status : 400;
		return Response.json({
			status: "invalid",
			checkoutAllowed: false,
			amountPen: null,
			reasons: [error instanceof PublicApiError ? error.message : "No se pudo validar el pedido."],
			batchAccepting: false
		}, {
			status,
			headers: { "Cache-Control": "no-store, max-age=0" }
		});
	}
} } } });
var CHECKOUT_LEGAL_VERSION = "2026-10-28";
var deliveryDistricts = [
	"Lince",
	"Jesus Maria",
	"San Isidro",
	"Miraflores",
	"San Borja",
	"Pueblo Libre",
	"Magdalena",
	"Surquillo",
	"La Victoria",
	"Cercado de Lima",
	"Brena",
	"Barranco",
	"San Miguel",
	"Surco",
	"Santiago de Surco",
	"San Luis",
	"Chorrillos",
	"La Molina",
	"Rimac",
	"San Juan de Miraflores",
	"Ate",
	"Los Olivos",
	"San Martin de Porres",
	"Villa El Salvador",
	"Villa Maria del Triunfo",
	"Other"
];
var deliveryRatePerKm = 3;
var minimumDeliveryFee = 8;
var longDistanceDiscountThreshold = 15;
var districtDeliveryDistancesKm = {
	Lince: 1.3,
	"Jesus Maria": 1.5,
	"San Isidro": 3.3,
	Miraflores: 7.1,
	"San Borja": 7.4,
	"Pueblo Libre": 3.7,
	Magdalena: 4.4,
	Surquillo: 7.9,
	"La Victoria": 3.3,
	"Cercado de Lima": 5.2,
	Brena: 3.8,
	Barranco: 10.4,
	"San Miguel": 6.4,
	Surco: 10.8,
	"Santiago de Surco": 10.8,
	"San Luis": 6.6,
	Chorrillos: 17.1,
	"La Molina": 17,
	Rimac: 8.6,
	"San Juan de Miraflores": 12.9,
	Ate: 20,
	"Los Olivos": 16.5,
	"San Martin de Porres": 16.3,
	"Villa El Salvador": 22.4,
	"Villa Maria del Triunfo": 21.1,
	Other: 10
};
function getDeliveryFee(district) {
	const km = districtDeliveryDistancesKm[district] ?? districtDeliveryDistancesKm.Other;
	const baseFee = Math.ceil(km * deliveryRatePerKm);
	const adjusted = baseFee >= longDistanceDiscountThreshold ? Math.ceil(baseFee * .7) : baseFee;
	return Math.max(minimumDeliveryFee, adjusted);
}
function isSupportedDistrict(district) {
	return deliveryDistricts.includes(district);
}
function text(value, max = 240) {
	return typeof value === "string" ? value.trim().slice(0, max) : "";
}
function validEmail(value) {
	return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}
function validPhone(value) {
	return value.replace(/\D/g, "").length >= 7;
}
function validUuid$3(value) {
	return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}
async function nextOrderCode() {
	const { data, error } = await createSupabaseAdminClient().rpc("next_order_code");
	if (!error && typeof data === "string" && data.trim()) return data.trim().toUpperCase();
	return "BAG-" + Date.now().toString(36).toUpperCase() + "-" + randomBytes(2).toString("hex").toUpperCase();
}
function packSlug(quantity, mix) {
	const slug = quantity + "-" + mix;
	return [
		"6-mixed",
		"12-mixed",
		"6-single",
		"12-single"
	].includes(slug) ? slug : null;
}
function normalizeItems(items) {
	return [...items].map((item) => ({
		flavor_slug: item.flavor_slug,
		quantity: Number(item.quantity)
	})).sort((a, b) => a.flavor_slug.localeCompare(b.flavor_slug));
}
function sameItems(a, b) {
	return JSON.stringify(normalizeItems(a)) === JSON.stringify(normalizeItems(b));
}
async function createGuidedCheckoutSession(request, input) {
	const checkoutSessionId = text(input.checkoutSessionId, 80).toLowerCase();
	const customerName = text(input.customerName, 120);
	const email = text(input.email, 160).toLowerCase();
	const whatsapp = text(input.whatsapp, 40);
	const deliveryAddress = text(input.deliveryAddress, 220);
	const district = text(input.district, 80);
	const addressReference = text(input.addressReference, 160);
	const deliveryNotes = text(input.deliveryNotes, 500);
	const trapValue = text(input.website, 120);
	if (!validUuid$3(checkoutSessionId)) throw new PublicApiError("Checkout session inválida.", 400);
	if (customerName.length < 2 || !validEmail(email) || !validPhone(whatsapp) || deliveryAddress.length < 5 || !isSupportedDistrict(district)) throw new PublicApiError("Completa datos válidos de cliente y delivery.", 400);
	if (input.termsAccepted !== true || input.termsVersion !== "2026-10-28") throw new PublicApiError("Debes aceptar los términos vigentes antes de pagar.", 400);
	await enforcePublicApiSecurity({
		request,
		scope: "reservations",
		email,
		whatsapp,
		trapValue
	});
	const quote = await quoteGuidedOrder(input);
	if (!quote.checkoutAllowed || quote.status !== "ready" || typeof quote.amountPen !== "number") throw new PublicApiError(quote.reasons[0] || "Este pedido no está habilitado para checkout.", 409);
	if (input.category !== "packs" || input.packFormat !== "grande") throw new PublicApiError("Este tipo de pedido todavía no está habilitado para checkout automático.", 409);
	const quantity = Number(input.packQty);
	const bagels = input.bagels && typeof input.bagels === "object" && !Array.isArray(input.bagels) ? Object.entries(input.bagels).filter(([, qty]) => Number(qty) > 0).map(([flavorId, qty]) => ({
		flavorId,
		quantity: Number(qty)
	})) : [];
	const effectiveMix = bagels.length === 1 ? "single" : "mixed";
	const slug = packSlug(quantity, effectiveMix);
	if (!slug) throw new PublicApiError("Pack no compatible con checkout actual.", 409);
	const menu = getVerifiedDisplayMenu();
	const items = bagels.map((row) => {
		const flavor = menu.bagels.find((item) => item.id === row.flavorId);
		if (!flavor || !Number.isInteger(row.quantity) || row.quantity < 1) throw new PublicApiError("Sabor inválido.", 400);
		return {
			flavor_name: flavor.name,
			flavor_slug: flavor.id,
			quantity: row.quantity
		};
	});
	const deliveryFee = getDeliveryFee(district);
	const totalAmount = quote.amountPen + deliveryFee;
	const supabase = createSupabaseAdminClient();
	async function readExisting() {
		const { data: existing, error } = await supabase.from("orders").select("id,order_code,email,pack_slug,total_amount,payment_expires_at,status").eq("checkout_session_id", checkoutSessionId).maybeSingle();
		if (error) {
			const missingMigration = error.code === "42703";
			throw new PublicApiError(missingMigration ? "La migración transaccional de Culqi no está instalada." : "No se pudo verificar la sesión.", missingMigration ? 503 : 500);
		}
		if (!existing) return null;
		const { data: persistedItems, error: itemError } = await supabase.from("order_items").select("flavor_slug,quantity").eq("order_id", existing.id);
		if (itemError) throw new PublicApiError("No se pudo verificar la sesión.", 500);
		if (String(existing.email).trim().toLowerCase() !== email || existing.pack_slug !== slug || Number(existing.total_amount) !== totalAmount || !sameItems(items, persistedItems ?? [])) throw new PublicApiError("La sesión de checkout no coincide con este pedido.", 409);
		if (existing.status === "cancelled") throw new PublicApiError("Esta sesión de pago venció. Inicia una nueva.", 410);
		return {
			ok: true,
			amountPen: Number(existing.total_amount),
			amountMinor: Math.round(Number(existing.total_amount) * 100),
			checkoutSessionId,
			expiresAt: String(existing.payment_expires_at ?? ""),
			orderCode: String(existing.order_code),
			currency: "PEN"
		};
	}
	const existing = await readExisting();
	if (existing) return existing;
	const { data: batch, error: batchError } = await supabase.from("batches").select("id,status,orders_open_at,orders_close_at,delivery_date").order("created_at", { ascending: false }).limit(1).maybeSingle();
	if (batchError || !batch?.id) throw new PublicApiError("No hay un batch disponible.", 503);
	const now = Date.now();
	const opens = batch.orders_open_at ? Date.parse(batch.orders_open_at) : NaN;
	const closes = batch.orders_close_at ? Date.parse(batch.orders_close_at) : NaN;
	if (batch.status !== "orders_open" || batch.orders_open_at && (!Number.isFinite(opens) || now < opens) || batch.orders_close_at && (!Number.isFinite(closes) || now >= closes)) throw new PublicApiError("El batch actual no está aceptando pedidos.", 409);
	if (!batch.delivery_date || !Number.isFinite(Date.parse(batch.delivery_date))) throw new PublicApiError("El batch todavía no tiene una fecha de delivery confirmada.", 409);
	const orderCode = await nextOrderCode();
	const paymentExpiresAt = new Date(Date.now() + 18e5).toISOString();
	const { error } = await supabase.rpc("create_culqi_reservation_order", {
		p_address_reference: addressReference || null,
		p_batch_id: batch.id,
		p_checkout_session_id: checkoutSessionId,
		p_customer_name: customerName,
		p_delivery_address: deliveryAddress,
		p_delivery_notes: deliveryNotes || null,
		p_district: district,
		p_email: email,
		p_items: items,
		p_marketing_opt_in: false,
		p_order_code: orderCode,
		p_pack_name: quantity + " " + effectiveMix,
		p_pack_slug: slug,
		p_pack_type: effectiveMix,
		p_pack_units: quantity,
		p_payment_expires_at: paymentExpiresAt,
		p_terms_accepted: true,
		p_total_amount: totalAmount,
		p_whatsapp: whatsapp
	}).single();
	if (error) {
		const missingRpc = error.code === "42883" || error.message?.toLowerCase().includes("create_culqi_reservation_order");
		throw new PublicApiError(missingRpc ? "La migración transaccional de Culqi no está instalada." : "No se pudo reservar el pedido.", missingRpc ? 503 : 500);
	}
	const persisted = await readExisting();
	if (!persisted) throw new PublicApiError("La reserva no devolvió un pedido válido.", 500);
	return persisted;
}
function configuredSiteUrl() {
	return process.env.PUBLIC_SITE_URL || process.env.NEXT_PUBLIC_SITE_URL || "";
}
function siteHost() {
	try {
		return new URL(configuredSiteUrl()).hostname;
	} catch {
		return "";
	}
}
function buildPaymentConfig() {
	const provider = process.env.PAYMENT_PROVIDER === "culqi" ? "culqi" : "manual";
	const publicKey = (process.env.CULQI_PUBLIC_KEY || process.env.NEXT_PUBLIC_CULQI_PUBLIC_KEY || "").trim();
	const rsaId = (process.env.CULQI_RSA_ID || process.env.NEXT_PUBLIC_CULQI_RSA_ID || "").trim();
	const rsaPublicKey = (process.env.CULQI_RSA_PUBLIC_KEY || process.env.NEXT_PUBLIC_CULQI_RSA_PUBLIC_KEY || "").trim();
	const secretKey = (process.env.CULQI_SECRET_KEY || "").trim();
	const requestedMode = process.env.CULQI_MODE === "sandbox" ? "sandbox" : process.env.CULQI_MODE === "live" ? "live" : "disabled";
	const matchingKeys = requestedMode === "sandbox" ? publicKey.startsWith("pk_test_") && secretKey.startsWith("sk_test_") : requestedMode === "live" ? publicKey.startsWith("pk_live_") && secretKey.startsWith("sk_live_") : false;
	const host = siteHost();
	const sandboxOriginAllowed = Boolean(host) && !(/* @__PURE__ */ new Set([
		"bagelito.pe",
		"www.bagelito.pe",
		"bagelito-pe.vercel.app"
	])).has(host);
	const modeAllowed = requestedMode === "sandbox" ? process.env.VERCEL_ENV !== "production" && sandboxOriginAllowed : requestedMode === "live" && process.env.CULQI_LIVE_APPROVED === "true";
	const configured = provider === "culqi" && matchingKeys && modeAllowed && Boolean(host) && Boolean(publicKey && rsaId && rsaPublicKey && secretKey);
	const merchantReviewOnly = process.env.BAGELITO_MERCHANT_REVIEW_ONLY === "true";
	const intakeEnabled = process.env.CULQI_ENABLED === "true" && !merchantReviewOnly;
	const bridgeReady = process.env.CULQI_TANSTACK_BRIDGE_READY === "true";
	const webhookReady = process.env.CULQI_TANSTACK_WEBHOOK_READY === "true";
	const clientReady = process.env.CULQI_TANSTACK_CLIENT_READY === "true";
	const visualQaAllowed = process.env.BAGELITO_VISUAL_QA_ENABLED === "true" && process.env.VERCEL_ENV !== "production";
	return {
		mode: requestedMode,
		currency: "PEN",
		enabled: configured && intakeEnabled && bridgeReady && webhookReady && clientReady,
		configured,
		intakeEnabled,
		bridgeReady,
		webhookReady,
		clientReady,
		merchantReviewOnly,
		visualQaAllowed,
		provider,
		publicKey: configured ? publicKey : "",
		rsaId: configured ? rsaId : "",
		rsaPublicKey: configured ? rsaPublicKey : "",
		secretKey: configured ? secretKey : ""
	};
}
function getPublicPaymentConfig() {
	const { secretKey: _secretKey, ...publicConfig } = buildPaymentConfig();
	return publicConfig;
}
function getPrivatePaymentConfig() {
	return buildPaymentConfig();
}
function requestMatchesConfiguredOrigin(request) {
	const configuredSite = configuredSiteUrl();
	try {
		const expected = new URL(configuredSite);
		if (new URL(request.url).origin !== expected.origin) return false;
		const origin = request.headers.get("origin");
		if (origin && origin !== expected.origin) return false;
		const forwardedHost = request.headers.get("x-forwarded-host");
		if (forwardedHost && forwardedHost !== expected.host) return false;
		const forwardedProto = request.headers.get("x-forwarded-proto");
		if (forwardedProto && forwardedProto !== expected.protocol.replace(":", "")) return false;
		return true;
	} catch {
		return false;
	}
}
/** New reservation / token / charge intake. */
function isPaymentRequestAllowed(request) {
	const cfg = buildPaymentConfig();
	return cfg.enabled && cfg.bridgeReady && requestMatchesConfiguredOrigin(request);
}
/**
* Read/recovery path for an already-created payment.
* It intentionally remains available when new intake is disabled so operators
* can close the front door without making in-flight payments unverifiable.
*/
function isPaymentStatusRequestAllowed(request) {
	const cfg = buildPaymentConfig();
	return cfg.configured && cfg.bridgeReady && requestMatchesConfiguredOrigin(request);
}
var Route$5 = createFileRoute("/api/checkout/session")({ server: { handlers: { POST: async ({ request }) => {
	try {
		if (!isPaymentRequestAllowed(request)) throw new PublicApiError("Culqi payments are not enabled yet.", 503);
		const result = await createGuidedCheckoutSession(request, await readBoundedJsonObject(request, 16384));
		return Response.json(result, { headers: { "Cache-Control": "no-store, max-age=0" } });
	} catch (error) {
		const status = error instanceof PublicApiError ? error.status : 500;
		const retryAfter = error instanceof PublicApiError ? error.retryAfterSeconds : null;
		return Response.json({
			ok: false,
			error: error instanceof PublicApiError ? error.message : "No se pudo iniciar el checkout."
		}, {
			status,
			headers: {
				"Cache-Control": "no-store, max-age=0",
				...retryAfter ? { "Retry-After": String(retryAfter) } : {}
			}
		});
	}
} } } });
function providerConfig() {
	const cfg = getPrivatePaymentConfig();
	if (!cfg.configured || !cfg.bridgeReady || !cfg.secretKey) throw new Error("Culqi provider access is not configured.");
	return cfg;
}
function intakeConfig() {
	const cfg = providerConfig();
	if (!cfg.enabled) throw new Error("Culqi payment intake is not enabled.");
	return cfg;
}
function minor(amountPen) {
	const value = Math.round(amountPen * 100);
	if (!Number.isInteger(value) || value < 100) throw new Error("Invalid payment amount.");
	return value;
}
function validSource(sourceId, mode) {
	return new RegExp("^(tkn|ype)_" + (mode === "sandbox" ? "test" : "live") + "_[A-Za-z0-9_-]{8,100}$").test(sourceId);
}
async function withinDeadline(operation) {
	const controller = new AbortController();
	const timeoutError = new DOMException("Culqi request deadline exceeded.", "TimeoutError");
	let timer;
	const deadline = new Promise((_, reject) => {
		timer = setTimeout(() => {
			controller.abort(timeoutError);
			reject(timeoutError);
		}, 1e4);
	});
	try {
		return await Promise.race([operation(controller.signal), deadline]);
	} finally {
		clearTimeout(timer);
	}
}
async function createCulqiCharge(input) {
	const cfg = intakeConfig();
	if (cfg.mode !== "sandbox" && cfg.mode !== "live") throw new Error("Culqi mode unavailable.");
	if (!validSource(input.sourceId, cfg.mode)) throw new Error("Invalid Culqi source.");
	if (input.sourceId.startsWith("ype_") && input.authentication3DS) throw new Error("Yape cannot use card 3DS.");
	if (input.sourceId.startsWith("ype_") && input.amountPen > 2e3) throw new Error("Yape supports a maximum of S/ 2000 per payment.");
	const parts = input.customerName.trim().split(/\s+/).filter(Boolean);
	const firstName = parts.shift() || "Cliente";
	const lastName = parts.join(" ") || "Bagelito";
	const digits = input.phoneNumber.replace(/\D/g, "");
	const phone = digits.startsWith("51") && digits.length === 11 ? digits.slice(2) : digits.slice(-9);
	const url = "https://api.culqi.com/v2/charges";
	const response = await withinDeadline((signal) => fetch(url, {
		method: "POST",
		signal,
		cache: "no-store",
		redirect: "error",
		credentials: "omit",
		headers: {
			Authorization: "Bearer " + cfg.secretKey,
			"Content-Type": "application/json",
			Accept: "application/json"
		},
		body: JSON.stringify({
			amount: minor(input.amountPen),
			capture: true,
			currency_code: "PEN",
			description: "Bagelito - " + input.orderCode,
			email: input.email.trim().toLowerCase(),
			metadata: { bagelito_order_code: input.orderCode },
			source_id: input.sourceId,
			antifraud_details: {
				address: input.address,
				address_city: input.district,
				country_code: "PE",
				email: input.email.trim().toLowerCase(),
				first_name: firstName,
				last_name: lastName,
				phone_number: phone,
				...input.deviceId ? { device_finger_print_id: input.deviceId } : {}
			},
			...input.authentication3DS ? { authentication_3DS: input.authentication3DS } : {}
		})
	}));
	if (response.redirected || response.url && response.url !== url) throw new Error("Culqi charge request cannot follow redirects.");
	const payload = await response.json().catch(() => null);
	if (!response.ok) {
		const message = payload && "user_message" in payload ? payload.user_message || payload.merchant_message : null;
		throw new Error(message || "Culqi charge failed.");
	}
	if (!payload || !("object" in payload) || payload.object !== "charge") throw new Error("Culqi did not return a valid charge.");
	const charge = payload;
	if (response.status === 200 && charge.action_code === "REVIEW") {
		if (typeof charge.id === "string" && charge.id) return {
			charge,
			requires3DS: false
		};
		if (charge.capture === true) throw new Error("Ambiguous Culqi authentication response.");
		return {
			response: charge,
			requires3DS: true
		};
	}
	if (response.status !== 201 || !charge.id) throw new Error("Culqi did not return a valid captured charge.");
	return {
		charge,
		requires3DS: false
	};
}
async function fetchCulqiCharge(chargeId) {
	const cfg = providerConfig();
	if (cfg.mode !== "sandbox" && cfg.mode !== "live") throw new Error("Culqi mode unavailable.");
	const env = cfg.mode === "sandbox" ? "test" : "live";
	if (!new RegExp("^chr_" + env + "_[A-Za-z0-9_-]{8,100}$").test(chargeId)) throw new Error("Invalid Culqi charge ID.");
	const url = "https://api.culqi.com/v2/charges/" + encodeURIComponent(chargeId);
	const response = await withinDeadline((signal) => fetch(url, {
		method: "GET",
		signal,
		cache: "no-store",
		redirect: "error",
		credentials: "omit",
		headers: {
			Authorization: "Bearer " + cfg.secretKey,
			"Content-Type": "application/json",
			Accept: "application/json",
			"x-api-version": "2",
			"x-culqi-env": env
		}
	}));
	if (response.redirected || response.url && response.url !== url) throw new Error("Culqi charge lookup cannot follow redirects.");
	const payload = await response.json().catch(() => null);
	if (!response.ok || !payload || payload.object !== "charge" || payload.id !== chargeId) throw new Error("Culqi charge could not be verified.");
	return payload;
}
async function fetchCulqiEvent(eventId) {
	const cfg = providerConfig();
	if (cfg.mode !== "sandbox" && cfg.mode !== "live") throw new Error("Culqi mode unavailable.");
	const env = cfg.mode === "sandbox" ? "test" : "live";
	if (!new RegExp(`^evt_${env}_[A-Za-z0-9_-]{8,40}$`).test(eventId)) throw new Error("Invalid Culqi event ID.");
	const url = "https://api.culqi.com/v2/events/" + encodeURIComponent(eventId);
	const controller = new AbortController();
	const deadlineAt = Date.now() + 1e4;
	const timeoutError = new DOMException("Culqi event lookup deadline exceeded.", "TimeoutError");
	let timer;
	const remaining = () => {
		const value = deadlineAt - Date.now();
		if (value <= 0) {
			controller.abort(timeoutError);
			throw timeoutError;
		}
		return value;
	};
	const request = async (headers) => {
		remaining();
		const requestPromise = fetch(url, {
			method: "GET",
			signal: controller.signal,
			cache: "no-store",
			redirect: "error",
			credentials: "omit",
			headers: {
				Authorization: "Bearer " + cfg.secretKey,
				Accept: "application/json",
				...headers
			}
		});
		const timeoutPromise = new Promise((_, reject) => {
			clearTimeout(timer);
			timer = setTimeout(() => {
				controller.abort(timeoutError);
				reject(timeoutError);
			}, remaining());
		});
		return await Promise.race([requestPromise, timeoutPromise]);
	};
	try {
		let response = await request({
			"x-api-version": "2",
			"x-culqi-env": env
		});
		if (response.redirected || response.url && response.url !== url) throw new Error("Culqi event lookup cannot follow redirects.");
		let payload = await response.json().catch(() => null);
		remaining();
		if (!response.ok && response.status === 400 && payload && typeof payload === "object" && !Array.isArray(payload) && payload.type === "parameter_error") {
			response = await request({});
			if (response.redirected || response.url && response.url !== url) throw new Error("Culqi event lookup cannot follow redirects.");
			payload = await response.json().catch(() => null);
			remaining();
		}
		if (!response.ok || !payload || typeof payload !== "object" || Array.isArray(payload)) throw new Error("Culqi event could not be verified.");
		const event = payload;
		if (event.id !== eventId || event.object !== "event" || typeof event.type !== "string") throw new Error("Culqi returned an invalid event.");
		return event;
	} finally {
		clearTimeout(timer);
	}
}
function record$1(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}
function parseCulqiEventResource(value) {
	let resource = value;
	if (typeof resource === "string") try {
		resource = JSON.parse(resource);
	} catch {
		return null;
	}
	return record$1(resource) ? resource : null;
}
function verifyCulqiEventIdentity(requestedId, event) {
	if (event.id !== requestedId || typeof event.type !== "string" || !event.type.trim()) throw new Error("Culqi returned an invalid event identity or type.");
	return event.type;
}
async function resolveVerifiedCulqiChargeCurrency(eventType, eventResource, getCharge) {
	if (eventType !== "charge.creation.succeeded" || eventResource.object !== "charge" || Object.prototype.hasOwnProperty.call(eventResource, "currency_code") || Object.prototype.hasOwnProperty.call(eventResource, "currency")) return eventResource;
	const id = eventResource.id;
	const amount = eventResource.amount;
	const source = eventResource.source;
	const metadata = eventResource.metadata;
	if (typeof id !== "string" || !/^chr_(test|live)_[A-Za-z0-9_-]{8,100}$/.test(id) || !Number.isSafeInteger(amount) || Number(amount) <= 0 || !record$1(source) || typeof source.id !== "string" || !/^(?:tkn|ype)_(test|live)_[A-Za-z0-9_-]{8,100}$/.test(source.id) || id.split("_")[1] !== source.id.split("_")[1] || !record$1(metadata) || typeof metadata.bagelito_order_code !== "string" || !/^BAG-[A-Z0-9_-]{1,80}$/.test(metadata.bagelito_order_code)) throw new Error("Authenticated Culqi charge evidence is incomplete or inconsistent.");
	const charge = await getCharge(id);
	if (!record$1(charge) || charge.object !== "charge" || charge.id !== id || charge.amount !== amount || charge.currency_code !== "PEN" || Object.prototype.hasOwnProperty.call(charge, "currency") && charge.currency !== "PEN" || !record$1(charge.metadata) || charge.metadata.bagelito_order_code !== metadata.bagelito_order_code || !record$1(charge.source) || charge.source.id !== source.id || charge.capture !== true || charge.current_amount !== amount || charge.amount_refunded !== 0 || charge.dispute !== false) throw new Error("Authenticated Culqi charge evidence is incomplete or inconsistent.");
	return {
		...eventResource,
		currency_code: "PEN"
	};
}
var supportedEvents = /* @__PURE__ */ new Set([
	"order.status.changed",
	"charge.creation.succeeded",
	"charge.creation.failed",
	"charge.expired"
]);
var Route$4 = createFileRoute("/api/webhooks/culqi")({ server: { handlers: { POST: async ({ request }) => {
	const headers = {
		"Cache-Control": "no-store, max-age=0",
		"CDN-Cache-Control": "no-store",
		"X-Content-Type-Options": "nosniff"
	};
	try {
		const cfg = getPrivatePaymentConfig();
		if (!cfg.configured || !cfg.bridgeReady || !cfg.webhookReady || !cfg.secretKey) return Response.json({
			ok: false,
			error: "Culqi webhook is not enabled yet."
		}, {
			status: 503,
			headers
		});
		const received = await readBoundedJsonObject(request, 8192);
		const eventId = String(received.id ?? "").trim();
		const env = cfg.mode === "sandbox" ? "test" : cfg.mode === "live" ? "live" : null;
		if (!env || !new RegExp("^evt_" + env + "_[A-Za-z0-9_-]{8,40}$").test(eventId)) return Response.json({
			ok: false,
			error: "A valid Culqi event ID is required."
		}, {
			status: 400,
			headers
		});
		const verified = await fetchCulqiEvent(eventId);
		const eventType = verifyCulqiEventIdentity(eventId, verified);
		const resource = parseCulqiEventResource(verified.data);
		if (eventType.startsWith("refund.") || resource?.object === "refund") return Response.json({
			ok: false,
			error: "Refund reconciliation requires review."
		}, {
			status: 501,
			headers
		});
		if (!supportedEvents.has(eventType)) return Response.json({
			ok: true,
			ignored: true
		}, { headers });
		if (!resource || typeof resource.id !== "string" || !resource.id) return Response.json({
			ok: false,
			error: "Webhook payment data is missing."
		}, {
			status: 400,
			headers
		});
		const reconciledResource = await resolveVerifiedCulqiChargeCurrency(eventType, resource, fetchCulqiCharge);
		const { data, error } = await createSupabaseAdminClient().rpc("apply_culqi_payment_event", {
			p_event_id: eventId,
			p_event_type: eventType,
			p_resource: reconciledResource,
			p_verified_payload: verified
		});
		if (error || !data || typeof data !== "object" || Array.isArray(data)) return Response.json({
			ok: false,
			error: "Could not process Culqi webhook."
		}, {
			status: 500,
			headers
		});
		return Response.json({
			ok: true,
			...data
		}, { headers });
	} catch {
		return Response.json({
			ok: false,
			error: "Could not process Culqi webhook."
		}, {
			status: 500,
			headers
		});
	}
} } } });
function record(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}
function field(value, name) {
	const descriptor = Object.getOwnPropertyDescriptor(value, name);
	if (!descriptor) return {
		present: false,
		value: void 0
	};
	if (!Object.prototype.hasOwnProperty.call(descriptor, "value")) throw new Error("Unusable charge evidence.");
	return {
		present: true,
		value: descriptor.value
	};
}
function validateCulqiChargeResult(charge, expected) {
	const reject = (reason, needsLookup = false) => Object.freeze({
		verified: false,
		reason,
		needsLookup
	});
	if (!Number.isSafeInteger(expected.amountMinor) || expected.amountMinor <= 0 || !["test", "live"].includes(expected.mode) || !new RegExp("^chr_" + expected.mode + "_[A-Za-z0-9_-]{8,100}$").test(expected.chargeId) || !new RegExp("^(?:tkn|ype)_" + expected.mode + "_[A-Za-z0-9_-]{8,100}$").test(expected.sourceId) || !/^BAG-[A-Z0-9_-]{1,80}$/.test(expected.orderCode) || expected.currencyCode !== "PEN") return reject("invalid_binding");
	try {
		if (!record(charge)) return reject("malformed_charge");
		let missing = false;
		const object = field(charge, "object");
		if (!object.present) missing = true;
		else if (object.value !== "charge") return reject("identity_mismatch");
		const id = field(charge, "id");
		if (!id.present) missing = true;
		else if (id.value !== expected.chargeId) return reject("identity_mismatch");
		const amount = field(charge, "amount");
		if (!amount.present) missing = true;
		else if (!Number.isSafeInteger(amount.value) || amount.value !== expected.amountMinor) return reject("amount_mismatch");
		const currencyCode = field(charge, "currency_code");
		const currency = field(charge, "currency");
		if (!currencyCode.present && !currency.present) missing = true;
		if (currencyCode.present && currencyCode.value !== "PEN" || currency.present && currency.value !== "PEN") return reject("currency_mismatch");
		const metadata = field(charge, "metadata");
		if (!metadata.present) missing = true;
		else if (!record(metadata.value) || field(metadata.value, "bagelito_order_code").value !== expected.orderCode) return reject("order_mismatch");
		const source = field(charge, "source");
		if (!source.present) missing = true;
		else if (!record(source.value) || field(source.value, "id").value !== expected.sourceId) return reject("source_mismatch");
		const capture = field(charge, "capture");
		if (!capture.present) missing = true;
		else if (capture.value !== true) return reject("capture_not_confirmed");
		const currentAmount = field(charge, "current_amount");
		if (!currentAmount.present) missing = true;
		else if (!Number.isSafeInteger(currentAmount.value) || currentAmount.value !== expected.amountMinor) return reject("current_amount_mismatch");
		const refunded = field(charge, "amount_refunded");
		if (!refunded.present) missing = true;
		else if (!Number.isSafeInteger(refunded.value) || refunded.value !== 0) return reject("refund_observed");
		const dispute = field(charge, "dispute");
		if (!dispute.present) missing = true;
		else if (dispute.value !== false) return reject("dispute_observed");
		if (field(charge, "action_code").value === "REVIEW") return reject("authentication_required");
		if (missing) return reject("evidence_incomplete", true);
		const captureDate = field(charge, "capture_date");
		return Object.freeze({
			verified: true,
			reason: "captured",
			needsLookup: false,
			evidence: Object.freeze({
				chargeId: expected.chargeId,
				sourceId: expected.sourceId,
				amountMinor: expected.amountMinor,
				currencyCode: "PEN",
				capture: true,
				currentAmountMinor: expected.amountMinor,
				amountRefundedMinor: 0,
				dispute: false,
				captureDatePresent: captureDate.present && captureDate.value != null
			})
		});
	} catch {
		return reject("malformed_charge");
	}
}
async function coordinateCulqiCharge(input) {
	if (!Number.isSafeInteger(input.amountMinor) || input.amountMinor <= 0 || !new RegExp("^(?:tkn|ype)_" + input.mode + "_[A-Za-z0-9_-]{8,100}$").test(input.sourceId)) throw new Error("Invalid charge confirmation context.");
	const claimResult = await input.db.rpc("claim_culqi_charge", {
		p_order_id: input.orderId,
		p_source_id: input.sourceId,
		p_device_id: input.deviceId,
		p_has_3ds: input.has3DS
	});
	if (claimResult.error) throw new Error(claimResult.error.message);
	const claim = claimResult.data;
	if (!claim?.claimed || !claim.attempt_id) {
		if (claim?.state === "paid") return {
			ok: true,
			orderCode: input.orderCode,
			paymentStatus: "paid"
		};
		if (claim?.state === "submitted" || claim?.state === "submitting") return {
			ok: true,
			orderCode: input.orderCode,
			paymentStatus: "awaiting_webhook"
		};
		return {
			ok: false,
			orderCode: input.orderCode,
			paymentStatus: "reconciliation_required",
			error: "This payment cannot be retried automatically."
		};
	}
	const finish = (state, chargeId, payload) => input.db.rpc("finish_culqi_charge", {
		p_order_id: input.orderId,
		p_attempt_id: claim.attempt_id,
		p_state: state,
		p_charge_id: chargeId,
		p_method: input.sourceId.startsWith("ype_") ? "yape" : "card",
		p_payload: payload
	});
	let knownChargeId = null;
	const review = () => ({
		ok: false,
		orderCode: input.orderCode,
		paymentStatus: "reconciliation_required",
		error: "We could not confirm the payment result. Do not pay again yet."
	});
	try {
		const result = await input.createCharge();
		if (result.requires3DS) {
			const stored = await finish("requires_3ds", null, {
				stage: "requires_3ds",
				action_code: "REVIEW"
			});
			if (stored.error) throw new Error(stored.error.message);
			return {
				ok: true,
				orderCode: input.orderCode,
				paymentStatus: "requires_3ds",
				requires3DS: true
			};
		}
		if (typeof result.charge.id === "string" && new RegExp("^chr_" + input.mode + "_[A-Za-z0-9_-]{8,100}$").test(result.charge.id)) knownChargeId = result.charge.id;
		if (!knownChargeId) throw new Error("Unbound charge identity.");
		const expected = {
			chargeId: knownChargeId,
			sourceId: input.sourceId,
			orderCode: input.orderCode,
			amountMinor: input.amountMinor,
			currencyCode: "PEN",
			mode: input.mode
		};
		let observation = validateCulqiChargeResult(result.charge, expected);
		let provenance = "culqi_charge_post";
		let observedAt = (/* @__PURE__ */ new Date()).toISOString();
		if (!observation.verified && observation.needsLookup) {
			observation = validateCulqiChargeResult(await input.fetchCharge(knownChargeId), expected);
			provenance = "culqi_charge_get";
			observedAt = (/* @__PURE__ */ new Date()).toISOString();
		}
		if (!observation.verified) {
			const stored = await finish("uncertain", knownChargeId, {
				stage: "reconciliation_required",
				reason: observation.reason
			});
			if (stored.error) throw new Error(stored.error.message);
			return review();
		}
		const stored = await finish("submitted", knownChargeId, {
			stage: "submitted",
			provenance
		});
		if (stored.error) throw new Error(stored.error.message);
		const confirmed = await input.db.rpc("confirm_culqi_charge_result", {
			p_order_id: input.orderId,
			p_checkout_session_id: input.checkoutSessionId,
			p_charge_attempt_id: claim.attempt_id,
			p_observed_at: observedAt,
			p_provenance: provenance,
			p_mode: input.mode,
			p_observation: observation.evidence
		});
		if (confirmed.error) throw new Error(confirmed.error.message);
		const state = confirmed.data;
		if (state?.paymentState === "paid" && state.requiresReview === false && [
			"payment_confirmed",
			"in_production",
			"ready_for_delivery",
			"delivered"
		].includes(String(state.orderState))) return {
			ok: true,
			orderCode: input.orderCode,
			paymentStatus: "paid"
		};
		return review();
	} catch {
		try {
			await finish("uncertain", knownChargeId, { stage: "reconciliation_required" });
		} catch {}
		return review();
	}
}
function parse3DS(value) {
	if (value == null) return void 0;
	if (typeof value !== "object" || Array.isArray(value)) throw new PublicApiError("Invalid 3DS response.", 400);
	const p = value;
	const req = (key) => {
		const v = String(p[key] ?? "").trim();
		if (!v || v.length > 512) throw new PublicApiError("Invalid 3DS response.", 400);
		return v;
	};
	const directoryServerTransactionId = String(p.directoryServerTransactionId ?? "").trim();
	if (directoryServerTransactionId.length > 512) throw new PublicApiError("Invalid 3DS response.", 400);
	return {
		cavv: req("cavv"),
		eci: req("eci"),
		protocolVersion: req("protocolVersion"),
		xid: req("xid"),
		...directoryServerTransactionId ? { directoryServerTransactionId } : {}
	};
}
function validUuid$2(value) {
	return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}
var Route$3 = createFileRoute("/api/payments/culqi/charge")({ server: { handlers: { POST: async ({ request }) => {
	try {
		if (!isPaymentRequestAllowed(request)) throw new PublicApiError("Culqi payments are not enabled yet.", 503);
		const cfg = getPrivatePaymentConfig();
		if (!cfg.enabled || !cfg.bridgeReady || cfg.mode !== "sandbox" && cfg.mode !== "live") throw new PublicApiError("Culqi payments are not enabled yet.", 503);
		const payload = await readBoundedJsonObject(request, 8192);
		const checkoutSessionId = String(payload.checkoutSessionId ?? "").trim().toLowerCase();
		const orderCode = String(payload.orderCode ?? "").trim().toUpperCase();
		const email = String(payload.email ?? "").trim().toLowerCase();
		const sourceId = String(payload.sourceId ?? "").trim();
		const deviceId = String(payload.deviceId ?? "").trim();
		const authentication3DS = parse3DS(payload.authentication3DS);
		const env = cfg.mode === "sandbox" ? "test" : "live";
		if (!orderCode || !email || !validUuid$2(checkoutSessionId) || !new RegExp("^(tkn|ype)_" + env + "_[A-Za-z0-9_-]{8,100}$").test(sourceId) || sourceId.startsWith("tkn_") && !/^[A-Za-z0-9_-]{8,160}$/.test(deviceId) || sourceId.startsWith("ype_") && authentication3DS) throw new PublicApiError("Valid order, checkout session and Culqi token are required.", 400);
		await enforcePublicApiSecurity({
			request,
			scope: "payments",
			email
		});
		const supabase = createSupabaseAdminClient();
		const { data, error } = await supabase.from("orders").select("id,order_code,checkout_session_id,customer_name,email,whatsapp,delivery_address,district,total_amount,status,payment_status,payment_lane,payment_order_id,payment_expires_at").eq("order_code", orderCode).eq("checkout_session_id", checkoutSessionId).maybeSingle();
		if (error) throw new PublicApiError("Could not verify order.", 500);
		const order = data;
		if (!order || order.email.trim().toLowerCase() !== email) throw new PublicApiError("Order not found.", 404);
		if (order.status === "cancelled" || order.status === "delivered") throw new PublicApiError("This order cannot accept payment.", 409);
		if (order.payment_status === "paid") return Response.json({
			ok: true,
			orderCode,
			paymentStatus: "paid"
		}, { headers: { "Cache-Control": "no-store" } });
		if (order.payment_expires_at && Date.parse(order.payment_expires_at) <= Date.now()) throw new PublicApiError("This payment session expired.", 410);
		if (order.payment_order_id || order.payment_lane !== "token") throw new PublicApiError("This reservation cannot accept token charges.", 409);
		if (sourceId.startsWith("ype_") && Number(order.total_amount) > 2e3) throw new PublicApiError("Yape supports a maximum of S/ 2000 per payment.", 400);
		const amountMinor = Math.round(Number(order.total_amount) * 100);
		const result = await coordinateCulqiCharge({
			db: supabase,
			orderId: order.id,
			orderCode: order.order_code,
			checkoutSessionId,
			amountMinor,
			mode: env,
			sourceId,
			deviceId,
			has3DS: Boolean(authentication3DS),
			createCharge: () => createCulqiCharge({
				amountPen: Number(order.total_amount),
				authentication3DS,
				sourceId,
				email: order.email,
				orderCode: order.order_code,
				customerName: order.customer_name,
				phoneNumber: order.whatsapp,
				address: order.delivery_address,
				district: order.district,
				deviceId: deviceId || void 0
			}),
			fetchCharge: fetchCulqiCharge
		});
		return Response.json(result, {
			status: result.ok ? 200 : 409,
			headers: { "Cache-Control": "no-store, max-age=0" }
		});
	} catch (error) {
		const status = error instanceof PublicApiError ? error.status : 500;
		const retryAfter = error instanceof PublicApiError ? error.retryAfterSeconds : null;
		return Response.json({
			ok: false,
			error: error instanceof PublicApiError ? error.message : "Could not process Culqi payment."
		}, {
			status,
			headers: {
				"Cache-Control": "no-store, max-age=0",
				...retryAfter ? { "Retry-After": String(retryAfter) } : {}
			}
		});
	}
} } } });
var Route$2 = createFileRoute("/api/payments/culqi/config")({ server: { handlers: { GET: async () => Response.json(getPublicPaymentConfig(), { headers: {
	"Cache-Control": "no-store, max-age=0",
	"CDN-Cache-Control": "no-store"
} }) } } });
function validUuid$1(value) {
	return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}
var Route$1 = createFileRoute("/api/payments/culqi/order")({ server: { handlers: { POST: async ({ request }) => {
	try {
		if (!isPaymentRequestAllowed(request)) throw new PublicApiError("Culqi payments are not enabled yet.", 503);
		const cfg = getPrivatePaymentConfig();
		const payload = await readBoundedJsonObject(request, 4096);
		const checkoutSessionId = String(payload.checkoutSessionId ?? "").trim().toLowerCase();
		const orderCode = String(payload.orderCode ?? "").trim().toUpperCase();
		const email = String(payload.email ?? "").trim().toLowerCase();
		if (!validUuid$1(checkoutSessionId) || !/^BAG-[A-Z0-9_-]{1,80}$/.test(orderCode) || !email) throw new PublicApiError("Order code, checkout session and email are required.", 400);
		await enforcePublicApiSecurity({
			request,
			scope: "payments",
			email
		});
		const supabase = createSupabaseAdminClient();
		const { data: order, error } = await supabase.from("orders").select("id,order_code,checkout_session_id,email,payment_provider,payment_lane,payment_order_id,payment_status,status").eq("order_code", orderCode).eq("checkout_session_id", checkoutSessionId).maybeSingle();
		if (error) throw new PublicApiError("Could not verify order.", 500);
		if (!order || String(order.checkout_session_id).toLowerCase() !== checkoutSessionId || String(order.email).trim().toLowerCase() !== email) throw new PublicApiError("Order not found.", 404);
		if (order.payment_status === "paid") throw new PublicApiError("This order is already paid.", 409);
		if (order.status === "cancelled" || order.status === "delivered" || order.payment_provider !== "culqi" || order.payment_lane !== "token" || order.payment_order_id) throw new PublicApiError("This reservation cannot enter token checkout.", 409);
		const { data: session, error: sessionError } = await supabase.rpc("prepare_culqi_token_session", { p_order_id: order.id });
		if (sessionError || !session || typeof session !== "object") throw new PublicApiError("Payment is in progress, expired or requires review. Do not pay again.", 409);
		const prepared = session;
		if (typeof prepared.sessionId !== "string" || !prepared.sessionId || !Number.isSafeInteger(Number(prepared.amount)) || Number(prepared.amount) <= 0) throw new PublicApiError("Payment session could not be prepared.", 409);
		return Response.json({
			ok: true,
			sessionId: prepared.sessionId,
			amount: Number(prepared.amount),
			expiresAt: typeof prepared.expiresAt === "string" ? prepared.expiresAt : null,
			currency: cfg.currency,
			publicKey: cfg.publicKey
		}, { headers: { "Cache-Control": "no-store, max-age=0" } });
	} catch (error) {
		const status = error instanceof PublicApiError ? error.status : 500;
		const retryAfter = error instanceof PublicApiError ? error.retryAfterSeconds : null;
		return Response.json({
			ok: false,
			error: error instanceof PublicApiError ? error.message : "Could not prepare token checkout."
		}, {
			status,
			headers: {
				"Cache-Control": "no-store, max-age=0",
				...retryAfter ? { "Retry-After": String(retryAfter) } : {}
			}
		});
	}
} } } });
function validUuid(value) {
	return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}
var Route = createFileRoute("/api/payments/culqi/status")({ server: { handlers: { POST: async ({ request }) => {
	const headers = {
		"Cache-Control": "private, no-store, max-age=0",
		"CDN-Cache-Control": "no-store",
		"X-Content-Type-Options": "nosniff"
	};
	try {
		if (!isPaymentStatusRequestAllowed(request)) return Response.json({
			ok: false,
			error: "Culqi payments are not enabled yet."
		}, {
			status: 503,
			headers
		});
		const cfg = getPrivatePaymentConfig();
		if (!cfg.configured || !cfg.bridgeReady) return Response.json({
			ok: false,
			error: "Culqi payments are not enabled yet."
		}, {
			status: 503,
			headers
		});
		const payload = await readBoundedJsonObject(request, 4096);
		const checkoutSessionId = String(payload.checkoutSessionId ?? "").trim();
		const orderCode = String(payload.orderCode ?? "").trim().toUpperCase();
		if (!validUuid(checkoutSessionId) || !/^BAG-[A-Z0-9_-]{1,80}$/.test(orderCode)) return Response.json({
			ok: false,
			error: "Invalid payment status request."
		}, {
			status: 400,
			headers
		});
		await enforcePublicApiSecurity({
			request,
			scope: "payments"
		});
		const supabase = createSupabaseAdminClient();
		const { data, error } = await supabase.from("orders").select("id,order_code,payment_status,payment_expires_at,status,total_amount").eq("order_code", orderCode).eq("checkout_session_id", checkoutSessionId).abortSignal(AbortSignal.timeout(2e3)).maybeSingle();
		if (error) throw new Error("state_unavailable");
		if (!data) return Response.json({
			ok: false,
			error: "Payment not found."
		}, {
			status: 404,
			headers
		});
		const state = await supabase.rpc("expire_culqi_token_session", {
			p_order_id: data.id,
			p_checkout_session_id: checkoutSessionId
		}).abortSignal(AbortSignal.timeout(2e3));
		if (state.error || !state.data || typeof state.data !== "object") throw new Error("state_unavailable");
		const payment = state.data;
		if (typeof payment.paymentStatus !== "string" || ![
			"pending",
			"paid",
			"failed",
			"expired",
			"refunded"
		].includes(payment.paymentStatus) || typeof payment.orderStatus !== "string" || ![
			"payment_pending_review",
			"payment_confirmed",
			"needs_correction",
			"in_production",
			"ready_for_delivery",
			"delivered",
			"cancelled"
		].includes(payment.orderStatus) || typeof payment.reconciliationRequired !== "boolean") throw new Error("state_unavailable");
		return Response.json({
			ok: true,
			orderCode: data.order_code,
			expiresAt: data.payment_expires_at ? String(data.payment_expires_at) : null,
			paymentStatus: payment.paymentStatus,
			orderStatus: payment.orderStatus,
			amountPen: Number.isFinite(Number(data.total_amount)) ? Number(data.total_amount) : null,
			reconciliationRequired: payment.reconciliationRequired
		}, { headers });
	} catch (error) {
		const status = error instanceof PublicApiError ? error.status : 500;
		return Response.json({
			ok: false,
			error: error instanceof PublicApiError ? error.message : "Could not read payment status."
		}, {
			status,
			headers
		});
	}
} } } });
var rootRouteChildren = {
	IndexRoute: Route$11.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$12
	}),
	LegalRoute: Route$10.update({
		id: "/legal",
		path: "/legal",
		getParentRoute: () => Route$12
	}),
	PlayableRoute: Route$9.update({
		id: "/playable",
		path: "/playable",
		getParentRoute: () => Route$12
	}),
	ApiBatchRoute: Route$8.update({
		id: "/api/batch",
		path: "/api/batch",
		getParentRoute: () => Route$12
	}),
	ApiCatalogRoute: Route$7.update({
		id: "/api/catalog",
		path: "/api/catalog",
		getParentRoute: () => Route$12
	}),
	ApiCheckoutQuoteRoute: Route$6.update({
		id: "/api/checkout/quote",
		path: "/api/checkout/quote",
		getParentRoute: () => Route$12
	}),
	ApiCheckoutSessionRoute: Route$5.update({
		id: "/api/checkout/session",
		path: "/api/checkout/session",
		getParentRoute: () => Route$12
	}),
	ApiWebhooksCulqiRoute: Route$4.update({
		id: "/api/webhooks/culqi",
		path: "/api/webhooks/culqi",
		getParentRoute: () => Route$12
	}),
	ApiPaymentsCulqiChargeRoute: Route$3.update({
		id: "/api/payments/culqi/charge",
		path: "/api/payments/culqi/charge",
		getParentRoute: () => Route$12
	}),
	ApiPaymentsCulqiConfigRoute: Route$2.update({
		id: "/api/payments/culqi/config",
		path: "/api/payments/culqi/config",
		getParentRoute: () => Route$12
	}),
	ApiPaymentsCulqiOrderRoute: Route$1.update({
		id: "/api/payments/culqi/order",
		path: "/api/payments/culqi/order",
		getParentRoute: () => Route$12
	}),
	ApiPaymentsCulqiStatusRoute: Route.update({
		id: "/api/payments/culqi/status",
		path: "/api/payments/culqi/status",
		getParentRoute: () => Route$12
	})
};
var routeTree = Route$12._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		scrollRestoration: false
	});
}
export { CHECKOUT_LEGAL_VERSION, deliveryDistricts, getVerifiedDisplayMenu, router_exports };
