import { CHECKOUT_LEGAL_VERSION } from "./router-C9uZPpJk.mjs";
import { Link, require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/legal-BiX6ymNW.js
var import_jsx_runtime = require_jsx_runtime();
function LegalPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "legal-shell",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "legal-header",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						children: "← Volver a Bagelito"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: ["VERSIÓN ", CHECKOUT_LEGAL_VERSION] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Políticas de compra y delivery" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Estas condiciones describen cómo Bagelito.pe recibe, cobra, produce y entrega pedidos realizados mediante batches programados en Lima." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "1. Confirmación del pedido" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Un pedido queda confirmado únicamente cuando Bagelito recibe una confirmación válida del proveedor de pagos y el pedido figura como pagado en nuestros sistemas. Seleccionar productos o iniciar un checkout no separa stock por sí solo." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El checkout online solo se habilita cuando existe un batch abierto, capacidad disponible y una fecha de delivery confirmada." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "2. Productos y disponibilidad" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Bagelito produce alimentos artesanales en batches. Sabores, presentaciones y disponibilidad pueden variar según producción e ingredientes. El precio y la composición que rigen cada compra son los que el servidor valida y muestra antes del pago." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Si una configuración no tiene una regla comercial aprobada para cobro automático, el checkout se bloqueará en lugar de estimar un precio." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "3. Pagos" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Los medios de pago disponibles se muestran dentro del checkout seguro de Culqi. Los datos de tarjeta se ingresan directamente en el entorno de Culqi y no se almacenan en los servidores de Bagelito." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Si el resultado de un pago es incierto o requiere reconciliación, el cliente no debe volver a pagar hasta que el estado sea verificado. Bagelito podrá contactar al cliente para resolver el caso." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "4. Delivery" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El costo de delivery se calcula durante el checkout según el distrito seleccionado y se suma al total antes de generar la reserva. El pedido se entrega en la fecha del batch confirmada al momento de la compra." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El cliente debe proporcionar nombre, WhatsApp, email, distrito, dirección completa y cualquier referencia necesaria. Cambios posteriores a la confirmación dependen de disponibilidad de ruta." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "5. Recepción" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El cliente debe estar disponible durante la ventana coordinada. Si la entrega no puede completarse por dirección incorrecta, acceso restringido o ausencia del receptor, una reentrega dependerá de disponibilidad y puede generar un costo adicional." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "6. Cancelaciones y reembolsos" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Antes de la confirmación de pago, una reserva puede abandonarse sin generar una compra. Después de la confirmación, las solicitudes de cancelación se revisan según el estado de producción del batch." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Si Bagelito no puede producir o entregar un pedido confirmado por una causa atribuible a la operación, se coordinará la devolución correspondiente o una alternativa aceptada por el cliente. Los pagos duplicados se revisan y corrigen." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "7. Privacidad" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Bagelito utiliza los datos de contacto, pedido y delivery para procesar la compra, coordinar producción, atender consultas, prevenir fraude y realizar la entrega. Los datos no se venden a terceros." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Proveedores necesarios para la operación —como hosting, base de datos, pagos y delivery— pueden procesar la información únicamente para prestar esos servicios." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "8. Contacto" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Para consultas relacionadas con pedidos, pagos, delivery o privacidad, puedes escribir a ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "mailto:contacto@bagelito.pe",
					children: "contacto@bagelito.pe"
				}),
				"."
			] })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "legal-footer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Bagelito.pe · Lima, Perú" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "Volver al inicio"
				})]
			})
		]
	});
}
export { LegalPage as component };
