import { __toESM } from "../_runtime.mjs";
import { CHECKOUT_LEGAL_VERSION, deliveryDistricts, getVerifiedDisplayMenu } from "./router-C9uZPpJk.mjs";
import { require_jsx_runtime, require_react } from "../_libs/@tanstack/react-router+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/ReferenceStorefront-C5kQbN0Z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var categories = [
	{
		id: "packs",
		label: "Packs",
		left: 396,
		right: 660
	},
	{
		id: "combos",
		label: "Combos",
		left: 674,
		right: 951
	},
	{
		id: "schmears",
		label: "Schmears",
		left: 966,
		right: 1230
	}
];
var steps = [
	"Entrada",
	"Categoría",
	"Selecciona",
	"Revisa",
	"Pago"
];
var stepCentres = [
	540,
	658,
	775,
	892,
	1013
];
function ReferenceScene(props) {
	const [expanded, setExpanded] = (0, import_react.useState)(false);
	const scroll = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!expanded || !scroll.current) return;
		const box = scroll.current;
		box.scrollLeft = Math.max(0, box.scrollWidth * (813 / 1536) - box.clientWidth / 2);
	}, [expanded]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "reference-presentation",
		"aria-label": "Vitrina Bagelito",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "reference-scroll" + (expanded ? " is-expanded" : ""),
			ref: scroll,
			onFocusCapture: (event) => {
				if (event.target instanceof HTMLElement && event.target.matches(":focus-visible") && event.currentTarget.scrollWidth > event.currentTarget.clientWidth) event.target.scrollIntoView({
					block: "nearest",
					inline: "center",
					behavior: "auto"
				});
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "reference-art",
				"data-reference-art": "exact-approved-image",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						className: "reference-image",
						src: "/images/store-reference-approved.webp",
						width: 1536,
						height: 1024,
						alt: "Bagelito: vitrina de bagels y schmears con opciones Packs, Combos y Schmears",
						fetchPriority: "high",
						draggable: false
					}),
					categories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "reference-hotspot reference-category",
						"aria-label": item.label,
						"data-reference-category": item.id,
						style: {
							left: `${item.left / 1536 * 100}%`,
							top: `34.1796875%`,
							width: `${(item.right - item.left) / 1536 * 100}%`,
							height: `22.8515625%`
						},
						onClick: () => props.onCategory(item.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "reference-sr-only",
							children: item.label
						})
					}, item.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "reference-hotspot reference-menu",
						"aria-label": props.menuOpen ? "Cerrar menú" : "Abrir menú",
						"aria-expanded": !!props.menuOpen,
						onClick: props.onMenu,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "reference-sr-only",
							children: "Menú"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "reference-hotspot reference-cart" + (props.cartCount > 0 ? " is-dynamic" : ""),
						"aria-label": `Ver tu pedido: ${props.cartCount} productos`,
						"aria-expanded": !!props.cartOpen,
						onClick: props.onCart,
						children: props.cartCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							width: "18",
							height: "18",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "1.8",
							"aria-hidden": "true",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 8h14l1 13H4L5 8Z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M9 9V6a3 3 0 0 1 6 0v3" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"Tu pedido (",
							props.cartCount,
							")"
						] })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "reference-sr-only",
							children: "Tu pedido (0)"
						})
					}),
					props.dynamicChrome ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "reference-progress-live",
						"aria-label": "Pasos de compra",
						children: steps.map((label, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-label": `Ir a ${label}`,
							disabled: !props.accessibleSteps[index],
							"aria-current": props.progressIndex === index ? "step" : void 0,
							onClick: () => props.onStep(index),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								"aria-hidden": "true",
								children: index + 1
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
						}, label))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "reference-progress-hotspots",
						"aria-label": "Pasos de compra",
						children: steps.map((label, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "reference-hotspot reference-step",
							style: { "--step-x": `${stepCentres[index] / 1536 * 100}%` },
							"aria-label": `Ir a ${label}`,
							disabled: !props.accessibleSteps[index],
							"aria-current": props.progressIndex === index ? "step" : void 0,
							onClick: () => props.onStep(index),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "reference-sr-only",
								children: label
							})
						}, label))
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "reference-mobile-tools",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setExpanded((value) => !value),
				"aria-pressed": expanded,
				children: expanded ? "Ver imagen completa" : "Ampliar imagen para leer"
			}), expanded && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Desliza horizontalmente para recorrer la imagen." })]
		})]
	});
}
function formatManualOrderInquiry(input) {
	const header = input.category === "packs" ? "Pack de " + String(input.packQuantity || 0) + " bagels " + (input.format === "mini" ? "minis" : "grandes") + " (" + (input.packMix === "single" ? "un sabor" : "mixto") + ")" : input.category === "combos" ? input.comboName || "Combo 2 bagels + 1 schmear" : "Schmear individual (" + String(input.schmearSizeGrams || 120) + " g)";
	const bagels = input.bagels.filter((item) => Number.isInteger(item.quantity) && item.quantity > 0).map((item) => "- " + item.quantity + " × " + item.name);
	const schmears = input.schmears.filter((item) => Number.isInteger(item.quantity) && item.quantity > 0).map((item) => "- " + item.quantity + " × " + item.name + (input.category === "schmears" ? " (" + String(input.schmearSizeGrams || 120) + " g)" : ""));
	return [
		"Hola, Bagelito. Quisiera consultar la disponibilidad de este pedido:",
		"",
		header,
		...bagels.length ? [
			"",
			"Bagels:",
			...bagels
		] : [],
		...schmears.length ? [
			"",
			"Schmears:",
			...schmears
		] : [],
		"",
		"¿Me confirman la disponibilidad, el precio final, el delivery y la fecha del próximo batch?",
		"Entiendo que esta consulta no confirma ni paga el pedido."
	].join("\n");
}
function createManualOrderWhatsAppHref(input) {
	const message = formatManualOrderInquiry(input);
	return "https://wa.me/51917547745?text=" + encodeURIComponent(message);
}
var RECOVERY_KEY = "bagelito.culqi.pending.v1";
function loadScript(id, src) {
	return new Promise((resolve, reject) => {
		const existing = document.getElementById(id);
		if (existing?.dataset.ready === "true") return resolve();
		if (existing) {
			existing.addEventListener("load", () => resolve(), { once: true });
			existing.addEventListener("error", () => reject(/* @__PURE__ */ new Error("script-load-failed")), { once: true });
			return;
		}
		const script = document.createElement("script");
		script.id = id;
		script.src = src;
		script.defer = true;
		script.onload = () => {
			script.dataset.ready = "true";
			resolve();
		};
		script.onerror = () => reject(/* @__PURE__ */ new Error("script-load-failed"));
		document.body.appendChild(script);
	});
}
function readRecovery() {
	const raw = window.localStorage.getItem(RECOVERY_KEY);
	if (!raw) return null;
	try {
		const value = JSON.parse(raw);
		if (typeof value.checkoutSessionId === "string" && typeof value.orderCode === "string" && (value.state === "pending" || value.state === "review")) return {
			checkoutSessionId: value.checkoutSessionId,
			orderCode: value.orderCode,
			state: value.state
		};
	} catch {}
	return { invalid: true };
}
function setRecovery(session, state) {
	window.localStorage.setItem(RECOVERY_KEY, JSON.stringify({
		checkoutSessionId: session.checkoutSessionId,
		orderCode: session.orderCode,
		state
	}));
}
function clearRecovery(session) {
	const current = readRecovery();
	if (current && "checkoutSessionId" in current && current.checkoutSessionId === session.checkoutSessionId && current.orderCode === session.orderCode) window.localStorage.removeItem(RECOVERY_KEY);
}
async function jsonFetch(url, init, timeoutMs) {
	const controller = new AbortController();
	const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
	try {
		const response = await fetch(url, {
			...init,
			signal: controller.signal
		});
		return {
			response,
			result: await response.json()
		};
	} finally {
		window.clearTimeout(timeout);
	}
}
function CulqiBrowserCheckout(props) {
	const { config, customer, order, subtotalPen, onPaid, onReview } = props;
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [message, setMessage] = (0, import_react.useState)("");
	const checkoutRef = (0, import_react.useRef)(null);
	const sessionRef = (0, import_react.useRef)(null);
	const tokenRef = (0, import_react.useRef)(null);
	const busyRef = (0, import_react.useRef)(false);
	const callbackConsumedRef = (0, import_react.useRef)(false);
	const checkoutSessionIdRef = (0, import_react.useRef)(null);
	const reservationExpiresAtRef = (0, import_react.useRef)(null);
	const reservationTimerRef = (0, import_react.useRef)(null);
	const paymentAttemptStartedRef = (0, import_react.useRef)(false);
	const aliveRef = (0, import_react.useRef)(true);
	const review = (0, import_react.useCallback)((text) => {
		const session = sessionRef.current;
		if (session) setRecovery(session, "review");
		busyRef.current = true;
		setStatus("review");
		setMessage(text);
		onReview(text);
	}, [onReview]);
	const clearReservationTimer = (0, import_react.useCallback)(() => {
		if (reservationTimerRef.current !== null) {
			window.clearTimeout(reservationTimerRef.current);
			reservationTimerRef.current = null;
		}
	}, []);
	const expireReservation = (0, import_react.useCallback)(() => {
		if (!aliveRef.current) return;
		clearReservationTimer();
		try {
			checkoutRef.current?.close();
		} catch {}
		try {
			window.Culqi3DS?.reset();
		} catch {}
		if (paymentAttemptStartedRef.current || readRecovery()) {
			review("La reserva venció mientras el pago estaba en curso. No vuelvas a pagar hasta verificar el estado.");
			return;
		}
		busyRef.current = false;
		callbackConsumedRef.current = false;
		sessionRef.current = null;
		tokenRef.current = null;
		checkoutSessionIdRef.current = null;
		reservationExpiresAtRef.current = null;
		setStatus("expired");
		setMessage("Tu reserva venció y el cupo dejó de estar garantizado. Inicia un nuevo checkout.");
	}, [clearReservationTimer, review]);
	const checkReservationExpiry = (0, import_react.useCallback)(() => {
		const expiresAt = reservationExpiresAtRef.current;
		if (expiresAt !== null && Date.now() >= expiresAt) {
			expireReservation();
			return true;
		}
		return false;
	}, [expireReservation]);
	const scheduleReservationExpiry = (0, import_react.useCallback)((expiresAt) => {
		reservationExpiresAtRef.current = expiresAt;
		clearReservationTimer();
		const watch = () => {
			reservationTimerRef.current = null;
			if (!aliveRef.current || checkReservationExpiry()) return;
			const remaining = expiresAt - Date.now();
			reservationTimerRef.current = window.setTimeout(watch, Math.max(250, Math.min(remaining, 2147483647)));
		};
		watch();
	}, [checkReservationExpiry, clearReservationTimer]);
	const waitForPaid = (0, import_react.useCallback)(async (session) => {
		setStatus("confirming");
		for (let attempt = 0; attempt < 6; attempt += 1) {
			if (attempt > 0) await new Promise((resolve) => window.setTimeout(resolve, Math.min(1500 * (attempt + 1), 6e3)));
			const { response, result } = await jsonFetch("/api/payments/culqi/status", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					checkoutSessionId: session.checkoutSessionId,
					orderCode: session.orderCode
				})
			}, 1e4);
			if (!response.ok || result.reconciliationRequired === true) {
				review("El pago necesita revisión. No vuelvas a pagar; verifica el estado del pedido.");
				return;
			}
			if (result.paymentStatus === "paid") {
				clearReservationTimer();
				clearRecovery(session);
				busyRef.current = false;
				paymentAttemptStartedRef.current = false;
				setStatus("ready");
				onPaid({
					orderCode: session.orderCode,
					amountPen: session.amountMinor / 100
				});
				return;
			}
			if (result.paymentStatus === "failed" || result.paymentStatus === "expired") {
				clearReservationTimer();
				clearRecovery(session);
				busyRef.current = false;
				paymentAttemptStartedRef.current = false;
				sessionRef.current = null;
				tokenRef.current = null;
				checkoutSessionIdRef.current = null;
				reservationExpiresAtRef.current = null;
				setStatus("error");
				setMessage("El pago no se completó. Puedes iniciar un nuevo checkout.");
				return;
			}
		}
		review("No pudimos confirmar el resultado todavía. No vuelvas a pagar hasta revisar el pedido.");
	}, [
		clearReservationTimer,
		onPaid,
		review
	]);
	const submitToken = (0, import_react.useCallback)(async (session, tokenId, deviceId, authentication3DS) => {
		if (checkReservationExpiry()) return;
		paymentAttemptStartedRef.current = true;
		const { response, result } = await jsonFetch("/api/payments/culqi/charge", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				authentication3DS,
				checkoutSessionId: session.checkoutSessionId,
				deviceId,
				email: customer.email,
				orderCode: session.orderCode,
				sourceId: tokenId
			})
		}, 3e4);
		if (!response.ok || result.paymentStatus === "reconciliation_required") {
			review(result.error || "El resultado del pago necesita revisión. No vuelvas a pagar.");
			return;
		}
		if (result.requires3DS) {
			if (!tokenId.startsWith("tkn_") || !window.Culqi3DS) {
				review("No se pudo iniciar la autenticación bancaria.");
				return;
			}
			tokenRef.current = {
				tokenId,
				deviceId
			};
			setStatus("3ds");
			window.Culqi3DS.settings = {
				card: { email: customer.email.trim().toLowerCase() },
				charge: {
					totalAmount: session.amountMinor,
					returnUrl: window.location.href,
					currency: "PEN"
				}
			};
			await window.Culqi3DS.initAuthentication(tokenId);
			return;
		}
		clearReservationTimer();
		await waitForPaid(session);
	}, [
		checkReservationExpiry,
		clearReservationTimer,
		customer.email,
		review,
		waitForPaid
	]);
	const recoverPayment = (0, import_react.useCallback)(async () => {
		const recovered = readRecovery();
		if (!recovered || !("checkoutSessionId" in recovered)) {
			setStatus("review");
			setMessage("Existe una referencia de pago inválida. No vuelvas a pagar hasta revisarla.");
			return;
		}
		setStatus("confirming");
		setMessage("Consultando el estado del pago…");
		try {
			const { response, result } = await jsonFetch("/api/payments/culqi/status", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					checkoutSessionId: recovered.checkoutSessionId,
					orderCode: recovered.orderCode
				})
			}, 1e4);
			if (!response.ok || result.reconciliationRequired === true) {
				setStatus("review");
				setMessage("El pago necesita revisión. No vuelvas a pagar.");
				return;
			}
			if (result.paymentStatus === "paid") {
				clearReservationTimer();
				window.localStorage.removeItem(RECOVERY_KEY);
				busyRef.current = false;
				paymentAttemptStartedRef.current = false;
				setStatus("ready");
				setMessage("");
				onPaid({
					orderCode: recovered.orderCode,
					amountPen: typeof result.amountPen === "number" ? result.amountPen : null
				});
				return;
			}
			if (result.paymentStatus === "failed" || result.paymentStatus === "expired") {
				clearReservationTimer();
				window.localStorage.removeItem(RECOVERY_KEY);
				busyRef.current = false;
				paymentAttemptStartedRef.current = false;
				sessionRef.current = null;
				tokenRef.current = null;
				checkoutSessionIdRef.current = null;
				reservationExpiresAtRef.current = null;
				setStatus("idle");
				setMessage("La reserva anterior ya no está pendiente. Puedes iniciar un nuevo checkout.");
				return;
			}
			setStatus("review");
			setMessage("El pago sigue pendiente. No vuelvas a pagar todavía.");
		} catch {
			setStatus("review");
			setMessage("No pudimos consultar el pago. No vuelvas a pagar hasta verificarlo.");
		}
	}, [clearReservationTimer, onPaid]);
	const startCheckout = (0, import_react.useCallback)(async () => {
		if (!config.enabled || busyRef.current) return;
		if (readRecovery()) {
			await recoverPayment();
			return;
		}
		busyRef.current = true;
		setStatus("loading");
		setMessage("Preparando tu pedido…");
		try {
			await Promise.all([loadScript("culqi-custom-checkout", "https://js.culqi.com/checkout-js"), loadScript("culqi-3ds", "https://3ds.culqi.com")]);
			if (!window.CulqiCheckout || !window.Culqi3DS || !config.publicKey || !config.rsaId || !config.rsaPublicKey) throw new Error("Culqi no está disponible.");
			const checkoutSessionId = checkoutSessionIdRef.current ?? crypto.randomUUID();
			checkoutSessionIdRef.current = checkoutSessionId;
			const { response: reservationResponse, result: reservation } = await jsonFetch("/api/checkout/session", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					...order,
					...customer,
					checkoutSessionId,
					website: ""
				})
			}, 2e4);
			if (!reservationResponse.ok || !reservation.ok || !reservation.orderCode || !reservation.amountMinor) throw new Error(reservation.error || "No se pudo reservar el pedido.");
			const { response: prepResponse, result: prepared } = await jsonFetch("/api/payments/culqi/order", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					checkoutSessionId,
					email: customer.email,
					orderCode: reservation.orderCode
				})
			}, 15e3);
			if (!prepResponse.ok || !prepared.ok || !prepared.sessionId || !prepared.amount) throw new Error(prepared.error || "No se pudo preparar Culqi.");
			if (prepared.amount !== reservation.amountMinor) throw new Error("El monto preparado no coincide con la reserva.");
			const session = {
				amountMinor: prepared.amount,
				checkoutSessionId,
				expiresAt: prepared.expiresAt ?? reservation.expiresAt ?? null,
				orderCode: reservation.orderCode,
				sessionId: prepared.sessionId
			};
			const expiresAt = session.expiresAt ? Date.parse(session.expiresAt) : NaN;
			if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) {
				checkoutSessionIdRef.current = null;
				throw new Error("La reserva expiró antes de abrir el checkout.");
			}
			sessionRef.current = session;
			scheduleReservationExpiry(expiresAt);
			window.Culqi3DS.publicKey = config.publicKey;
			window.Culqi3DS.options = {
				showModal: true,
				showLoading: true,
				showIcon: true,
				closeModalAction: () => review("La autenticación bancaria fue cerrada. Revisa el estado antes de volver a pagar.")
			};
			const names = customer.customerName.trim().split(/\s+/);
			const firstName = names.shift() || "Cliente";
			const lastName = names.join(" ") || "Bagelito";
			const checkout = new window.CulqiCheckout(config.publicKey, {
				settings: {
					title: "Bagelito",
					currency: "PEN",
					amount: session.amountMinor,
					xculqirsaid: config.rsaId,
					rsapublickey: config.rsaPublicKey.replace(/\\n/g, "\n")
				},
				client: {
					email: customer.email.trim().toLowerCase(),
					firstName,
					lastName
				},
				options: {
					lang: "es",
					installments: true,
					modal: false,
					container: "#culqi-checkout-container",
					paymentMethods: {
						tarjeta: true,
						yape: session.amountMinor <= 2e5,
						billetera: false,
						bancaMovil: false,
						agente: false,
						cuotealo: false
					},
					paymentMethodsSort: ["yape", "tarjeta"]
				},
				appearance: {
					hiddenEmail: true,
					menuType: "sliderTop",
					theme: "default",
					variables: {
						colorPrimary: "#004aad",
						colorBackground: "#fffaf4",
						colorText: "#10243a",
						borderRadius: "16px"
					}
				}
			});
			checkoutRef.current = checkout;
			checkout.culqi = () => {
				if (!busyRef.current || callbackConsumedRef.current) return;
				callbackConsumedRef.current = true;
				const tokenId = checkout.token?.id;
				if (!tokenId) {
					callbackConsumedRef.current = false;
					busyRef.current = false;
					const error = checkout.error;
					setStatus("error");
					setMessage(error?.user_message || error?.merchant_message || error?.message || "Culqi no pudo generar el token.");
					return;
				}
				(async () => {
					try {
						checkout.close();
						setStatus("charging");
						window.Culqi3DS.publicKey = config.publicKey;
						const deviceId = tokenId.startsWith("tkn_") ? await window.Culqi3DS.generateDevice() : "";
						if (tokenId.startsWith("tkn_") && !deviceId) throw new Error("No se pudo generar el identificador antifraude.");
						if (checkReservationExpiry()) return;
						tokenRef.current = {
							tokenId,
							deviceId
						};
						setRecovery(session, "pending");
						await submitToken(session, tokenId, deviceId);
					} catch (error) {
						review(error instanceof Error ? error.message : "No se pudo procesar el pago.");
					}
				})();
			};
			busyRef.current = true;
			callbackConsumedRef.current = false;
			setStatus("ready");
			setMessage("");
			checkout.open();
		} catch (error) {
			busyRef.current = false;
			setStatus("error");
			setMessage(error instanceof Error ? error.message : "No se pudo iniciar Culqi.");
		}
	}, [
		checkReservationExpiry,
		config,
		customer,
		order,
		recoverPayment,
		review,
		scheduleReservationExpiry,
		submitToken
	]);
	(0, import_react.useEffect)(() => {
		function on3DSMessage(event) {
			if (event.origin !== window.location.origin || !event.data || typeof event.data !== "object") return;
			const data = event.data;
			if (data.error) {
				window.Culqi3DS?.reset();
				review("No se pudo completar la autenticación 3D Secure.");
				return;
			}
			if (!data.parameters3DS) return;
			const session = sessionRef.current;
			const token = tokenRef.current;
			if (!session || !token) {
				review("Se perdió la referencia del pago. No vuelvas a pagar.");
				return;
			}
			if (checkReservationExpiry()) return;
			setStatus("charging");
			submitToken(session, token.tokenId, token.deviceId, data.parameters3DS).finally(() => window.Culqi3DS?.reset());
		}
		window.addEventListener("message", on3DSMessage);
		return () => window.removeEventListener("message", on3DSMessage);
	}, [
		checkReservationExpiry,
		review,
		submitToken
	]);
	(0, import_react.useEffect)(() => {
		aliveRef.current = true;
		const onForeground = () => {
			checkReservationExpiry();
		};
		const onVisibility = () => {
			if (document.visibilityState === "visible") checkReservationExpiry();
		};
		window.addEventListener("focus", onForeground);
		window.addEventListener("pageshow", onForeground);
		document.addEventListener("visibilitychange", onVisibility);
		return () => {
			aliveRef.current = false;
			clearReservationTimer();
			window.removeEventListener("focus", onForeground);
			window.removeEventListener("pageshow", onForeground);
			document.removeEventListener("visibilitychange", onVisibility);
			try {
				checkoutRef.current?.close();
			} catch {}
			try {
				window.Culqi3DS?.reset();
			} catch {}
		};
	}, [checkReservationExpiry, clearReservationTimer]);
	const customerReady = customer.customerName.trim().length >= 2 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email.trim()) && customer.whatsapp.replace(/\D/g, "").length >= 7 && customer.deliveryAddress.trim().length >= 5 && customer.district.trim().length > 0 && customer.termsAccepted;
	if (!config.enabled) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "culqi-browser-status is-locked",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Checkout Culqi bloqueado" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			"Subtotal actual: S/ ",
			subtotalPen,
			". Se habilitará solo cuando cliente, webhook, datos legales y batch estén listos."
		] })]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "culqi-browser-checkout",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "culqi-start-button",
				disabled: !customerReady || status === "loading" || status === "charging" || status === "3ds" || status === "confirming" || status === "review",
				onClick: () => void startCheckout(),
				children: status === "loading" ? "Preparando…" : status === "expired" ? "Reserva vencida" : status === "charging" ? "Procesando…" : status === "3ds" ? "Autenticando banco…" : status === "confirming" ? "Confirmando pago…" : status === "review" ? "Pago en revisión" : "Pagar con Culqi"
			}),
			!customerReady && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "culqi-browser-message",
				children: "Completa tus datos y acepta los términos para habilitar el pago."
			}),
			message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "culqi-browser-message",
				children: message
			}),
			status === "review" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "culqi-recovery-button",
				onClick: () => void recoverPayment(),
				children: "Consultar estado del pago"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "culqi-checkout-container",
				className: "culqi-browser-container"
			})
		]
	});
}
var menu = getVerifiedDisplayMenu();
var optionalPackSchmearSize = menu.schmearSizes.find((size) => size.grams === 120);
var combos = [{
	id: "two-bagel-schmear",
	name: "2 Bagels + Schmear",
	bagels: 2,
	schmear_count: 1,
	price: null
}];
function revealFocusedCatalogCard(event) {
	const grid = event.currentTarget;
	if (grid.scrollWidth <= grid.clientWidth || !(event.target instanceof Element) || !event.target.matches(":focus-visible")) return;
	const card = event.target.closest(".mobile-bagel-card,.mobile-schmear-card");
	if (card && grid.contains(card)) card.scrollIntoView({
		block: "nearest",
		inline: "start",
		behavior: "auto"
	});
}
var BAGEL_SHOWCASE_ORDER = [
	"plain",
	"everything",
	"sesame",
	"classic-onion",
	"jalapeno-cheddar",
	"cheddar",
	"cinnamon-raisin",
	"blueberry"
];
var BAGEL_SPOTS = [
	{
		left: "6%",
		top: "7%",
		width: "19%",
		height: "43%"
	},
	{
		left: "25%",
		top: "7%",
		width: "25%",
		height: "43%"
	},
	{
		left: "50%",
		top: "7%",
		width: "25%",
		height: "43%"
	},
	{
		left: "75%",
		top: "7%",
		width: "25%",
		height: "43%"
	},
	{
		left: "6%",
		top: "53%",
		width: "19%",
		height: "44%"
	},
	{
		left: "25%",
		top: "53%",
		width: "25%",
		height: "44%"
	},
	{
		left: "50%",
		top: "53%",
		width: "25%",
		height: "44%"
	},
	{
		left: "75%",
		top: "53%",
		width: "25%",
		height: "44%"
	}
];
/** Inverted bagel signs: WHITE text on Bagelito BLUE plates, aligned to the printed labels
* in /images/bagel-vitrina-photo.webp (800 × 300 photograph). These are
* presentation only; product selection remains on the existing hotspots.
*/
var BAGEL_SIGN_POSITIONS = [
	{
		left: "6%",
		top: "32.5%",
		width: "21%",
		height: "12%"
	},
	{
		left: "29%",
		top: "32.5%",
		width: "21%",
		height: "12%"
	},
	{
		left: "52.5%",
		top: "32.5%",
		width: "21%",
		height: "12%"
	},
	{
		left: "76%",
		top: "32.5%",
		width: "21.5%",
		height: "12%"
	},
	{
		left: "5%",
		top: "77.5%",
		width: "22.5%",
		height: "12%"
	},
	{
		left: "28.5%",
		top: "77.5%",
		width: "22%",
		height: "12%"
	},
	{
		left: "52%",
		top: "77.5%",
		width: "22%",
		height: "12%"
	},
	{
		left: "75.5%",
		top: "77.5%",
		width: "22%",
		height: "12%"
	}
];
var GUIDED_DRAFT_KEY = "bagelito.guided.product-draft.v1";
var GUIDED_DRAFT_TTL_MS = 864e5;
function readSafeSelections(raw, allowedIds) {
	if (!raw || typeof raw !== "object" || Array.isArray(raw)) return {};
	const next = {};
	for (const [id, value] of Object.entries(raw)) if (allowedIds.includes(id) && typeof value === "number" && Number.isInteger(value) && value > 0 && value <= 24) next[id] = value;
	return next;
}
var SCHMEAR_SPOTS = [
	{
		left: "5%",
		top: "20%",
		width: "17%",
		height: "61%"
	},
	{
		left: "23%",
		top: "20%",
		width: "17%",
		height: "61%"
	},
	{
		left: "41%",
		top: "20%",
		width: "17%",
		height: "61%"
	},
	{
		left: "59%",
		top: "20%",
		width: "17%",
		height: "61%"
	},
	{
		left: "77%",
		top: "20%",
		width: "17%",
		height: "61%"
	}
];
function GuidedCommerce({ onExit, customerName, initialCategory = null, skipEntrance = false, liveWorld = false, onSceneChange, referenceMode = false, reviewOnly = false, exitLabel = "Explorar tienda 3D" }) {
	const [scene, setScene] = (0, import_react.useState)(initialCategory === "packs" ? "pack-size" : initialCategory === "combos" ? "combos" : initialCategory === "schmears" ? "schmear-size" : skipEntrance ? "selector" : "entrance");
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [cartOpen, setCartOpen] = (0, import_react.useState)(false);
	const [category, setCategory] = (0, import_react.useState)(initialCategory);
	const [packFormat, setPackFormat] = (0, import_react.useState)("grande");
	const [packQty, setPackQty] = (0, import_react.useState)(6);
	const [packMix, setPackMix] = (0, import_react.useState)("mixed");
	const [comboId, setComboId] = (0, import_react.useState)(null);
	const [schmearSize, setSchmearSize] = (0, import_react.useState)(120);
	const [bagelMode, setBagelMode] = (0, import_react.useState)("pack");
	const [bagelCounts, setBagelCounts] = (0, import_react.useState)({});
	const [schmearCounts, setSchmearCounts] = (0, import_react.useState)({});
	const [receiptPulled, setReceiptPulled] = (0, import_react.useState)(false);
	const [walletSaved, setWalletSaved] = (0, import_react.useState)(false);
	const [paidOrderCode, setPaidOrderCode] = (0, import_react.useState)(null);
	const [paidAmountPen, setPaidAmountPen] = (0, import_react.useState)(null);
	const [paymentReviewMessage, setPaymentReviewMessage] = (0, import_react.useState)("");
	const [checkoutCustomer, setCheckoutCustomer] = (0, import_react.useState)({
		customerName: customerName ?? "",
		email: "",
		whatsapp: "",
		deliveryAddress: "",
		district: "",
		addressReference: "",
		deliveryNotes: "",
		termsAccepted: false,
		termsVersion: CHECKOUT_LEGAL_VERSION
	});
	const [paymentConfig, setPaymentConfig] = (0, import_react.useState)(null);
	const [checkoutQuote, setCheckoutQuote] = (0, import_react.useState)(null);
	const [quoteLoading, setQuoteLoading] = (0, import_react.useState)(false);
	const [draftLoaded, setDraftLoaded] = (0, import_react.useState)(false);
	const qaRequested = typeof window !== "undefined" && new URLSearchParams(window.location.search).get("qa") === "1";
	const qaMode = !referenceMode && !reviewOnly && qaRequested && paymentConfig?.visualQaAllowed === true;
	const directCatalog = liveWorld || referenceMode;
	const receiptDrag = (0, import_react.useRef)({
		startY: 0,
		offset: 0
	});
	const receiptPulledRef = (0, import_react.useRef)(false);
	const sceneChangeCallback = (0, import_react.useRef)(onSceneChange);
	(0, import_react.useEffect)(() => {
		if (reviewOnly) {
			setDraftLoaded(true);
			return;
		}
		try {
			if (!initialCategory) {
				const raw = window.sessionStorage.getItem(GUIDED_DRAFT_KEY);
				if (raw) {
					const draft = JSON.parse(raw);
					const age = Date.now() - Number(draft.updatedAt);
					if (!Number.isFinite(age) || age < 0 || age > GUIDED_DRAFT_TTL_MS || ![
						"packs",
						"combos",
						"schmears"
					].includes(String(draft.category))) window.sessionStorage.removeItem(GUIDED_DRAFT_KEY);
					else {
						const restoredCategory = draft.category;
						const safeBagels = readSafeSelections(draft.bagels, menu.bagels.map((item) => item.id));
						const safeSchmears = readSafeSelections(draft.schmears, menu.schmears.map((item) => item.id));
						const safeFormat = draft.format === "mini" ? "mini" : "grande";
						const safeQty = (safeFormat === "mini" ? [
							6,
							12,
							24
						] : [6, 12]).includes(Number(draft.packQty)) ? Number(draft.packQty) : 6;
						const safeMix = draft.packMix === "single" ? "single" : "mixed";
						const safeSize = [
							120,
							180,
							240
						].includes(Number(draft.schmearSize)) ? Number(draft.schmearSize) : 120;
						const restoredScene = String(draft.scene);
						const requestedScene = [
							"selector",
							"pack-size",
							"pack-qty",
							"combos",
							"schmear-size",
							"bagels",
							"schmears",
							"cashier"
						].includes(restoredScene) ? restoredScene : restoredCategory === "schmears" ? "schmear-size" : "pack-size";
						const requiredBagels = restoredCategory === "combos" ? 2 : safeQty;
						const bagelTotal = Object.values(safeBagels).reduce((sum, n) => sum + n, 0);
						const schmearTotal = Object.values(safeSchmears).reduce((sum, n) => sum + n, 0);
						const complete = restoredCategory === "schmears" ? schmearTotal === 1 : restoredCategory === "packs" ? bagelTotal === requiredBagels : bagelTotal === 2 && schmearTotal === 1;
						setCategory(restoredCategory);
						setPackFormat(safeFormat);
						setPackQty(safeQty);
						setPackMix(safeMix);
						setComboId(restoredCategory === "combos" ? "two-bagel-schmear" : null);
						setSchmearSize(safeSize);
						setBagelMode(restoredCategory === "combos" ? "combo" : "pack");
						setBagelCounts(safeBagels);
						setSchmearCounts(safeSchmears);
						setScene(requestedScene === "cashier" && !complete ? restoredCategory === "schmears" ? "schmears" : "bagels" : requestedScene);
					}
				}
			}
		} catch {}
		setDraftLoaded(true);
	}, [initialCategory, reviewOnly]);
	(0, import_react.useEffect)(() => {
		if (reviewOnly || !draftLoaded) return;
		try {
			if (!category || paidOrderCode || [
				"receipt",
				"wallet",
				"handoff",
				"goodbye",
				"returning"
			].includes(scene)) {
				window.sessionStorage.removeItem(GUIDED_DRAFT_KEY);
				return;
			}
			window.sessionStorage.setItem(GUIDED_DRAFT_KEY, JSON.stringify({
				updatedAt: Date.now(),
				category,
				scene: scene === "pay" ? "cashier" : scene,
				format: packFormat,
				packQty,
				packMix,
				schmearSize,
				bagels: bagelCounts,
				schmears: schmearCounts
			}));
		} catch {}
	}, [
		draftLoaded,
		category,
		scene,
		packFormat,
		packQty,
		packMix,
		schmearSize,
		bagelCounts,
		schmearCounts,
		paidOrderCode,
		reviewOnly
	]);
	(0, import_react.useEffect)(() => {
		setMenuOpen(false);
		setCartOpen(false);
	}, [scene]);
	(0, import_react.useEffect)(() => {
		if (!menuOpen && !cartOpen) return;
		const dismissOnEscape = (event) => {
			if (event.key === "Escape") {
				event.preventDefault();
				setMenuOpen(false);
				setCartOpen(false);
			}
		};
		window.addEventListener("keydown", dismissOnEscape);
		return () => window.removeEventListener("keydown", dismissOnEscape);
	}, [menuOpen, cartOpen]);
	(0, import_react.useEffect)(() => {
		if (customerName) setCheckoutCustomer((current) => current.customerName.trim() ? current : {
			...current,
			customerName
		});
	}, [customerName]);
	(0, import_react.useEffect)(() => {
		if (reviewOnly) {
			setPaymentConfig(null);
			return;
		}
		let active = true;
		fetch("/api/payments/culqi/config", { cache: "no-store" }).then(async (response) => {
			if (!response.ok) throw new Error("payment-config-unavailable");
			return await response.json();
		}).then((config) => {
			if (active) setPaymentConfig({
				enabled: config.enabled === true,
				configured: config.configured === true,
				intakeEnabled: config.intakeEnabled === true,
				bridgeReady: config.bridgeReady === true,
				webhookReady: config.webhookReady === true,
				clientReady: config.clientReady === true,
				visualQaAllowed: config.visualQaAllowed === true,
				mode: typeof config.mode === "string" ? config.mode : "disabled",
				currency: config.currency === "PEN" ? "PEN" : "PEN",
				publicKey: typeof config.publicKey === "string" ? config.publicKey : "",
				rsaId: typeof config.rsaId === "string" ? config.rsaId : "",
				rsaPublicKey: typeof config.rsaPublicKey === "string" ? config.rsaPublicKey : ""
			});
		}).catch(() => {
			if (active) setPaymentConfig({
				enabled: false,
				configured: false,
				intakeEnabled: false,
				bridgeReady: false,
				webhookReady: false,
				clientReady: false,
				visualQaAllowed: false,
				mode: "disabled",
				currency: "PEN",
				publicKey: "",
				rsaId: "",
				rsaPublicKey: ""
			});
		});
		return () => {
			active = false;
		};
	}, [reviewOnly]);
	(0, import_react.useEffect)(() => {
		if (reviewOnly) {
			setQuoteLoading(false);
			setCheckoutQuote(null);
			return;
		}
		if (scene !== "cashier" || paymentConfig === null) return;
		if (qaMode) {
			setQuoteLoading(false);
			setCheckoutQuote({
				status: "review_required",
				checkoutAllowed: false,
				amountPen: null,
				reasons: ["Preview visual · el precio final se valida en servidor antes de cobrar."]
			});
			return;
		}
		if (paymentConfig.enabled !== true) {
			setQuoteLoading(false);
			setCheckoutQuote({
				status: "manual_inquiry",
				checkoutAllowed: false,
				amountPen: null,
				reasons: []
			});
			return;
		}
		let active = true;
		setQuoteLoading(true);
		setCheckoutQuote(null);
		fetch("/api/checkout/quote", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			cache: "no-store",
			body: JSON.stringify({
				category,
				packFormat,
				packQty,
				packMix,
				bagels: bagelCounts,
				schmears: schmearCounts,
				schmearSize,
				comboId,
				bagelMode
			})
		}).then(async (response) => {
			const result = await response.json();
			return {
				status: typeof result.status === "string" ? result.status : "invalid",
				checkoutAllowed: result.checkoutAllowed === true,
				amountPen: typeof result.amountPen === "number" ? result.amountPen : null,
				reasons: Array.isArray(result.reasons) ? result.reasons.filter((x) => typeof x === "string") : []
			};
		}).then((quote) => {
			if (active) setCheckoutQuote(quote);
		}).catch(() => {
			if (active) setCheckoutQuote({
				status: "invalid",
				checkoutAllowed: false,
				amountPen: null,
				reasons: ["No se pudo validar el pedido."]
			});
		}).finally(() => {
			if (active) setQuoteLoading(false);
		});
		return () => {
			active = false;
		};
	}, [
		scene,
		category,
		packFormat,
		packQty,
		packMix,
		bagelCounts,
		schmearCounts,
		schmearSize,
		comboId,
		bagelMode,
		paymentConfig,
		qaMode,
		reviewOnly
	]);
	const selectedCombo = combos.find((c) => c.id === comboId) ?? null;
	const bagelTotal = Object.values(bagelCounts).reduce((sum, n) => sum + n, 0);
	const schmearTotal = Object.values(schmearCounts).reduce((sum, n) => sum + n, 0);
	const selectedBagelSummary = menu.bagels.filter((item) => (bagelCounts[item.id] ?? 0) > 0).map((item) => ({
		name: item.name,
		quantity: bagelCounts[item.id] ?? 0
	}));
	const selectedSchmearSummary = menu.schmears.filter((item) => (schmearCounts[item.id] ?? 0) > 0).map((item) => ({
		name: item.name,
		quantity: schmearCounts[item.id] ?? 0
	}));
	const bagelTarget = bagelMode === "upsell8" ? 8 : bagelMode === "downsell2" ? 2 : category === "packs" ? packQty : selectedCombo?.bagels ?? 0;
	const schmearTarget = category === "combos" ? selectedCombo?.schmear_count ?? 0 : 1;
	const progressIndex = scene === "entrance" || scene === "selector" || scene === "pack-size" || scene === "pack-qty" || scene === "combos" || scene === "schmear-size" ? 0 : scene === "bagels" ? 1 : scene === "schmears" || scene === "cross-sell" ? 2 : scene === "cashier" ? 3 : 4;
	const sceneImage = (0, import_react.useMemo)(() => {
		const base = "/master-scenes-clean/";
		if (scene === "entrance") return "/store-entry-door.webp";
		if (scene === "selector") return base + "selector.webp";
		if (scene === "pack-size" || scene === "pack-qty") return base + "packs.webp";
		if (scene === "combos") return base + "combos.webp";
		if (scene === "schmear-size") return base + "schmears.webp";
		if (scene === "bagels") return "/images/bagel-vitrina-photo.webp";
		if (scene === "schmears") return base + "schmears-vitrina.webp";
		if (scene === "cross-sell") return base + "cross-sell.webp";
		if (scene === "cashier") return base + "cashier.webp";
		if (scene === "pay") return base + "pay.webp";
		if (scene === "receipt") return base + "receipt.webp";
		if (scene === "wallet") return "/store-entry-door.webp";
		if (scene === "handoff") return base + "bag-handoff.webp";
		if (scene === "returning") return "/store-entry-door.webp";
		if (scene === "goodbye") return "/store-entry-door.webp";
		return base + "goodbye.webp";
	}, [scene]);
	(0, import_react.useEffect)(() => {
		if (referenceMode || typeof window === "undefined") return;
		const base = "/master-scenes-clean/";
		const assets = (scene === "pay" ? [base + "receipt.webp"] : scene === "receipt" ? ["/store-entry-door.webp"] : scene === "wallet" ? [base + "bag-handoff.webp"] : scene === "handoff" ? ["/store-entry-door.webp"] : scene === "selector" ? [
			base + "packs.webp",
			base + "combos.webp",
			base + "schmears.webp"
		] : []).map((src) => {
			const image = new window.Image();
			image.src = src;
			return image;
		});
		return () => {
			assets.length = 0;
		};
	}, [scene, referenceMode]);
	(0, import_react.useEffect)(() => {
		sceneChangeCallback.current = onSceneChange;
	}, [onSceneChange]);
	(0, import_react.useEffect)(() => {
		sceneChangeCallback.current?.(scene);
	}, [scene]);
	function resetSelections() {
		setBagelCounts({});
		setSchmearCounts({});
	}
	function chooseCategory(value) {
		if (value !== category) {
			resetSelections();
			setComboId(null);
		}
		setCategory(value);
		if (value === "packs") setScene("pack-size");
		if (value === "combos") setScene("combos");
		if (value === "schmears") setScene("schmear-size");
	}
	function choosePackFormat(format) {
		if (format !== packFormat) {
			setBagelCounts({});
			setSchmearCounts({});
			setPackQty(6);
			setPackMix("mixed");
		}
		setPackFormat(format);
		setScene("pack-qty");
	}
	function choosePackMix(mix) {
		if (mix === packMix) return;
		setPackMix(mix);
		setBagelCounts({});
		setSchmearCounts({});
	}
	function choosePack(qty, mix) {
		if (qty !== packQty || mix !== packMix) {
			setBagelCounts({});
			setSchmearCounts({});
		}
		setPackQty(qty);
		setPackMix(mix);
		setBagelMode("pack");
		setScene("bagels");
	}
	function chooseCombo(id) {
		if (id !== comboId) resetSelections();
		setComboId(id);
		setBagelMode("combo");
		setScene("bagels");
	}
	function chooseSchmearSize(grams) {
		if (grams !== schmearSize) setSchmearCounts({});
		setSchmearSize(grams);
		setScene("schmears");
	}
	function addBagel(id) {
		setBagelCounts((current) => {
			if (bagelMode === "pack" && packMix === "single") return { [id]: bagelTarget };
			if (Object.values(current).reduce((sum, n) => sum + n, 0) >= bagelTarget) return current;
			return {
				...current,
				[id]: (current[id] ?? 0) + 1
			};
		});
	}
	function removeBagel(id) {
		setBagelCounts((current) => {
			const n = current[id] ?? 0;
			if (!n) return current;
			if (bagelMode === "pack" && packMix === "single") return {};
			const next = { ...current };
			if (n === 1) delete next[id];
			else next[id] = n - 1;
			return next;
		});
	}
	function addSchmear(id) {
		setSchmearCounts((current) => {
			if (category !== "combos" || schmearTarget === 1) return current[id] ? {} : { [id]: 1 };
			if (Object.values(current).reduce((sum, n) => sum + n, 0) >= schmearTarget) return current;
			return {
				...current,
				[id]: (current[id] ?? 0) + 1
			};
		});
	}
	function removeSchmear(id) {
		setSchmearCounts((current) => {
			const n = current[id] ?? 0;
			if (!n) return current;
			const next = { ...current };
			if (n === 1) delete next[id];
			else next[id] = n - 1;
			return next;
		});
	}
	function nextFromBagels() {
		if (bagelTotal !== bagelTarget) return;
		if (bagelMode === "upsell8" || bagelMode === "downsell2") {
			setScene("cashier");
			return;
		}
		setScene("schmears");
	}
	function nextFromSchmears() {
		if (category === "schmears") {
			setScene(qaMode ? "cross-sell" : "cashier");
			return;
		}
		if (category === "packs") {
			setScene("cashier");
			return;
		}
		if (schmearTotal === schmearTarget) setScene("cashier");
	}
	function acceptPrimaryUpsell() {
		setBagelMode("upsell8");
		setBagelCounts({});
		setScene("bagels");
	}
	function acceptDownsell() {
		setBagelMode("downsell2");
		setBagelCounts({});
		setScene("bagels");
	}
	function pullReceipt() {
		if (receiptPulledRef.current) return;
		receiptPulledRef.current = true;
		setReceiptPulled(true);
		window.setTimeout(() => setScene(referenceMode ? "handoff" : "wallet"), 700);
	}
	function saveWallet() {
		setWalletSaved(true);
		window.setTimeout(() => setScene("handoff"), 650);
	}
	const showProgress = ![
		"entrance",
		"pay",
		"receipt",
		"wallet",
		"handoff",
		"goodbye",
		"returning"
	].includes(scene);
	const visibleCartCount = bagelTotal + schmearTotal;
	const canEditOrder = reviewOnly && scene === "pay" || [
		"selector",
		"pack-size",
		"pack-qty",
		"combos",
		"schmear-size",
		"bagels",
		"schmears",
		"cross-sell",
		"cashier"
	].includes(scene);
	const canGoBack = canEditOrder && scene !== "entrance" || scene === "pay" && qaMode;
	const canReviewAtCashier = category === "schmears" ? schmearTotal === 1 : category === "packs" ? bagelTotal === bagelTarget : category === "combos" && bagelTotal === bagelTarget && schmearTotal === schmearTarget;
	const canPayOnline = !reviewOnly && paymentConfig?.enabled === true && checkoutQuote?.checkoutAllowed === true;
	const manualOrderHref = !reviewOnly && category && canReviewAtCashier ? createManualOrderWhatsAppHref({
		category,
		format: packFormat,
		packQuantity: packQty,
		packMix,
		comboName: selectedCombo?.name,
		schmearSizeGrams: schmearSize,
		bagels: selectedBagelSummary,
		schmears: selectedSchmearSummary
	}) : null;
	function goBack() {
		const previous = scene === "selector" ? "entrance" : scene === "pack-size" ? "selector" : scene === "pack-qty" ? "pack-size" : scene === "combos" ? "selector" : scene === "schmear-size" ? "selector" : scene === "bagels" ? bagelMode === "upsell8" || bagelMode === "downsell2" ? "cross-sell" : category === "packs" ? "pack-qty" : "combos" : scene === "schmears" ? category === "schmears" ? "schmear-size" : "bagels" : scene === "cross-sell" ? "schmears" : scene === "cashier" ? bagelMode === "upsell8" || bagelMode === "downsell2" ? "bagels" : "schmears" : scene === "pay" && (qaMode || reviewOnly) ? "cashier" : null;
		if (previous) setScene(previous);
	}
	function jumpToStage(index) {
		if (!canEditOrder || index > progressIndex) return;
		if (index === 0) setScene("selector");
		if (index === 1 && category !== "schmears") setScene("bagels");
		if (index === 2 && (category === "schmears" || bagelTotal === bagelTarget)) setScene("schmears");
		if (index === 3 && canReviewAtCashier) setScene("cashier");
	}
	function goToEntrance() {
		setCategory(null);
		setComboId(null);
		resetSelections();
		setReceiptPulled(false);
		receiptPulledRef.current = false;
		setWalletSaved(false);
		setPaidOrderCode(null);
		setPaidAmountPen(null);
		setCheckoutQuote(null);
		setScene("entrance");
	}
	[
		"Elige",
		"Bagels",
		"Schmears",
		"Caja",
		"Pago"
	].map((_, index) => index <= progressIndex && index < 4 && (index === 0 || index === 1 && category !== "schmears" || index === 2 && (category === "schmears" || bagelTotal === bagelTarget) || index === 3 && canReviewAtCashier));
	const referenceProgressIndex = ["entrance", "selector"].includes(scene) ? 0 : [
		"pack-size",
		"pack-qty",
		"combos",
		"schmear-size"
	].includes(scene) ? 1 : [
		"bagels",
		"schmears",
		"cross-sell"
	].includes(scene) ? 2 : scene === "cashier" ? 3 : 4;
	const referenceAccessibleSteps = [
		true,
		!!category,
		!!category,
		canReviewAtCashier,
		false
	].map((available, index) => available && index <= referenceProgressIndex);
	function jumpToReferenceStage(index) {
		if (!canEditOrder || !referenceAccessibleSteps[index]) return;
		if (index === 0) setScene("selector");
		if (index === 1 && category) setScene(category === "packs" ? "pack-size" : category === "combos" ? "combos" : "schmear-size");
		if (index === 2 && category) setScene(category === "schmears" ? "schmears" : "bagels");
		if (index === 3 && canReviewAtCashier) setScene("cashier");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "guided-commerce" + (referenceMode ? " reference-mode" : ""),
		"data-scene": scene,
		"data-qa": qaMode ? "true" : "false",
		"data-live-world": liveWorld ? "true" : void 0,
		"data-direct-catalog": directCatalog ? "true" : void 0,
		"data-reference-mode": referenceMode ? "true" : void 0,
		"data-review-only": reviewOnly ? "true" : void 0,
		children: [
			referenceMode && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReferenceScene, {
				onCategory: (value) => {
					if (value === "packs") setSchmearSize(120);
					chooseCategory(value);
				},
				onMenu: () => {
					setMenuOpen((open) => !open);
					setCartOpen(false);
				},
				onCart: () => {
					setCartOpen((open) => !open);
					setMenuOpen(false);
				},
				cartCount: visibleCartCount,
				menuOpen,
				cartOpen,
				progressIndex: referenceProgressIndex,
				accessibleSteps: referenceAccessibleSteps,
				onStep: jumpToReferenceStage,
				dynamicChrome: !["entrance", "selector"].includes(scene) || visibleCartCount > 0
			}),
			!referenceMode && !liveWorld && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "guided-scene-backdrop",
				style: { backgroundImage: "url(\"" + sceneImage + "\")" }
			}, "backdrop-" + scene),
			!referenceMode && !liveWorld && scene !== "bagels" && scene !== "schmears" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				className: "guided-scene-image",
				src: sceneImage,
				alt: ""
			}, "master-" + scene),
			!referenceMode && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "guided-scene-vignette" }),
			!referenceMode && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "guided-store-topbar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "guided-store-menu-button",
					"aria-label": menuOpen ? "Cerrar menú" : "Abrir menú",
					"aria-expanded": menuOpen,
					onClick: () => {
						setMenuOpen((open) => !open);
						setCartOpen(false);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						width: "22",
						height: "22",
						viewBox: "0 0 24 24",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2",
						strokeLinecap: "round",
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 7h16M4 12h16M4 17h16" })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "guided-store-cart-button",
					"aria-label": "Ver tu pedido: " + visibleCartCount + " productos",
					"aria-expanded": cartOpen,
					onClick: () => {
						setCartOpen((open) => !open);
						setMenuOpen(false);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						width: "19",
						height: "19",
						viewBox: "0 0 24 24",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "1.8",
						strokeLinejoin: "round",
						strokeLinecap: "round",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 8h14l1 13H4L5 8Z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M9 9V6a3 3 0 0 1 6 0v3" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Tu pedido (",
						visibleCartCount,
						")"
					] })]
				})]
			}),
			canGoBack && (!referenceMode || !["entrance", "selector"].includes(scene)) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "guided-journey-back",
				onClick: goBack,
				"aria-label": "Volver al paso anterior",
				title: "Volver al paso anterior",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": "true",
					children: "←"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Volver" })]
			}),
			(menuOpen || cartOpen) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "guided-overlay-dismiss",
				"aria-label": "Cerrar panel abierto",
				onClick: () => {
					setMenuOpen(false);
					setCartOpen(false);
				}
			}),
			menuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "guided-store-menu-panel",
				"aria-label": "Menú Bagelito",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Bagelito" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: goToEntrance,
						children: "Inicio"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setScene("selector"),
						children: "Packs · Combos · Schmears"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onExit,
						children: exitLabel
					})
				]
			}),
			cartOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "guided-store-cart-panel",
				"aria-label": "Resumen de tu pedido",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Tu pedido" }),
					visibleCartCount === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Aún no has elegido productos." }),
					selectedBagelSummary.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["× ", item.quantity] })] }, "bagel-" + item.name)),
					selectedSchmearSummary.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["× ", item.quantity] })] }, "schmear-" + item.name)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: checkoutQuote?.checkoutAllowed && checkoutQuote.amountPen != null ? "Subtotal verificado: S/ " + checkoutQuote.amountPen.toFixed(2) : "Importe validado al pasar por caja." }),
					canEditOrder && category && visibleCartCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setCartOpen(false);
							setScene(category === "schmears" ? "schmears" : "bagels");
						},
						children: "Editar sabores"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setCartOpen(false),
						children: "Cerrar resumen"
					})
				]
			}),
			!referenceMode && showProgress && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "guided-progress-master",
				"aria-label": "Pasos de compra",
				children: [
					"Elige",
					"Bagels",
					"Schmears",
					"Caja",
					"Pago"
				].map((label, index) => {
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						"data-active": progressIndex === index,
						"data-done": progressIndex > index,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: !(index <= progressIndex && index < 4 && (index === 0 || index === 1 && category !== "schmears" || index === 2 && (category === "schmears" || bagelTotal === bagelTarget) || index === 3 && canReviewAtCashier)),
							"aria-current": progressIndex === index ? "step" : void 0,
							"aria-label": "Ir a " + label,
							onClick: () => jumpToStage(index),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { children: progressIndex > index ? "✓" : index + 1 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
						})
					}, label);
				})
			}),
			!referenceMode && scene === "entrance" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "guided-entrance-action",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "BAGELITO STORE" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Entra. Elige. Disfruta." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Una visita guiada, como entrar al Bagelito real." })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setScene("selector"),
					children: ["Entrar a Bagelito ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "→" })]
				})]
			}),
			!referenceMode && scene === "selector" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				customerName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "guided-welcome",
					children: [
						"Hola ",
						customerName,
						". ¿Qué te provoca hoy?"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "guided-selector-heading",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/bagelito-wordmark.svg",
						alt: "Bagelito"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "¿Qué te provoca hoy?" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "guided-selector-hitboxes live-selector-cards",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							"aria-label": "Packs",
							onClick: () => chooseCategory("packs"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "selector-product-photo selector-product-pack",
								role: "img",
								"aria-label": "Fotografía de un pack de bagels",
								"data-art-medium": "photograph-crop"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Packs" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Grandes o minis" })] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							"aria-label": "Combos",
							onClick: () => chooseCategory("combos"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "selector-product-photo selector-product-combo",
								role: "img",
								"aria-label": "Fotografía de dos bagels con schmear",
								"data-art-medium": "photograph-crop"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Combos" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "2 bagels + schmear" })] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							"aria-label": "Schmears",
							onClick: () => chooseCategory("schmears"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "selector-product-photo selector-product-schmear",
								role: "img",
								"aria-label": "Fotografía de un schmear",
								"data-art-medium": "photograph-crop"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Schmears" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "120 g · 180 g · 240 g" })] })]
						})
					]
				})
			] }),
			scene === "pack-size" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "guided-floating-panel pack-size-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "PACKS · PASO 1" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "¿Grandes o minis?" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Primero eliges el formato. Después cantidad y sabores." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pack-format-grid",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => choosePackFormat("grande"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pack-format-art",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/images/bagel-everything.webp",
										alt: ""
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Bagels grandes" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "6 o 12 bagels" })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { children: "→" })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => choosePackFormat("mini"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pack-format-art mini",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/images/bagel-plain.webp",
										alt: ""
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Mini bagels" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "6, 12 o 24 minis" })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { children: "→" })
							]
						})]
					})
				]
			}),
			scene === "pack-qty" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "guided-floating-panel pack-config-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "panel-back",
						onClick: () => setScene("pack-size"),
						children: "←"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: ["PACKS · ", packFormat === "mini" ? "MINIS" : "GRANDES"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Arma tu pack" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "guided-pack-mix",
						role: "group",
						"aria-label": "¿Cómo quieres combinar los sabores?",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-pressed": packMix === "mixed",
							onClick: () => choosePackMix("mixed"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Mixto" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Combina los sabores que quieras" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-pressed": packMix === "single",
							onClick: () => choosePackMix("single"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Un sabor" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Todos iguales, elige uno" })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "guided-pack-quantity-title",
						children: "Ahora elige la cantidad:"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pack-choice-grid",
						children: (packFormat === "mini" ? [
							6,
							12,
							24
						] : [6, 12]).map((qty) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => choosePack(qty, packMix),
							"aria-label": "Elegir " + qty + " " + (packFormat === "mini" ? "mini bagels" : "bagels") + ", " + (packMix === "single" ? "un sabor" : "mixtos"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: qty }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: packFormat === "mini" ? "mini bagels" : "bagels" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Elegir sabores →" })
							]
						}, qty))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: packMix === "single" ? "En la siguiente escena toca una vez el sabor que quieres para todo el pack." : "En la siguiente escena combina los sabores tocando los productos de la vitrina." })
				]
			}),
			scene === "combos" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "guided-combo-overlay approved-combo-overlay",
				children: combos.map((combo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => chooseCombo(combo.id),
					"aria-label": combo.name,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "approved-combo-art",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/images/bagel-everything.webp",
									alt: ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/images/bagel-sesame.webp",
									alt: ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "approved-schmear" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "approved-combo-copy",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "COMBO BAGELITO" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: combo.name }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Elige 2 bagels + 1 schmear" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Precio por confirmar" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "approved-combo-arrow",
							children: "→"
						})
					]
				}, combo.id))
			}),
			scene === "schmear-size" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "guided-floating-panel schmear-size-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "SCHMEARS" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Elige tamaño" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "guided-size-cards",
						children: menu.schmearSizes.map((size) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => chooseSchmearSize(size.grams),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [size.grams, " g"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Original S/",
								size.original_price,
								" · Sabores S/",
								size.flavoured_price
							] })]
						}, size.grams))
					})
				]
			}),
			scene === "bagels" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mobile-product-stage mobile-bagel-stage",
					"data-format": category === "packs" ? packFormat : "grande",
					"aria-label": "Selecciona sabores de bagels",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: ["VITRINA BAGELITO · ", packFormat === "mini" && category === "packs" ? "MINIS" : "GRANDES"] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: category === "packs" && packMix === "single" ? "Elige un sabor" : "Elige tus sabores" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: category === "packs" && packMix === "single" ? "Un toque completa todo tu pack." : bagelTotal + " de " + bagelTarget + " seleccionados" })
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mobile-bagel-grid",
						onFocusCapture: directCatalog ? revealFocusedCatalogCard : void 0,
						children: menu.bagels.map((bagel) => {
							const count = bagelCounts[bagel.id] ?? 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "mobile-bagel-card",
								"data-selected": count > 0,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => addBagel(bagel.id),
									"aria-label": "Agregar " + bagel.name,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: "/images/bagel-" + bagel.id + ".webp",
											alt: bagel.name,
											loading: "eager"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mobile-bagel-sign",
											children: bagel.name
										}),
										bagel.premium && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Premium" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											"aria-hidden": "true",
											children: count > 0 ? "✓" : "+"
										})
									]
								}), count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mobile-product-count",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => removeBagel(bagel.id),
										"aria-label": "Quitar " + bagel.name,
										children: "−"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: count })]
								})]
							}, bagel.id);
						})
					})]
				}),
				!directCatalog && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "guided-product-frame bagel-product-frame",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: sceneImage,
							alt: "Vitrina con ocho sabores de bagels"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bagel-vitrina-blue-labels",
							"aria-hidden": "true",
							children: BAGEL_SHOWCASE_ORDER.map((flavorId, index) => {
								const bagel = menu.bagels.find((item) => item.id === flavorId);
								return bagel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "bagel-vitrina-label",
									style: BAGEL_SIGN_POSITIONS[index],
									children: bagel.name
								}, flavorId) : null;
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "guided-product-hotspots bagel-hotspots",
							children: BAGEL_SHOWCASE_ORDER.map((flavorId, index) => {
								const bagel = menu.bagels.find((item) => item.id === flavorId);
								if (!bagel) return null;
								const count = bagelCounts[bagel.id] ?? 0;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									style: BAGEL_SPOTS[index],
									"data-selected": count > 0,
									onClick: () => addBagel(bagel.id),
									"aria-label": "Agregar " + bagel.name,
									children: [count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: count }), count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
										role: "button",
										onClick: (e) => {
											e.stopPropagation();
											removeBagel(bagel.id);
										},
										children: "−"
									})]
								}, bagel.id);
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "guided-order-counter bagel-live-summary",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: bagelMode === "upsell8" ? "6 + 2 GRATIS" : bagelMode === "downsell2" ? "PRUEBA CON 2" : category === "combos" ? selectedCombo?.name : packFormat === "mini" ? "MINIS" : "TU PACK" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
							bagelTotal,
							"/",
							bagelTarget
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bagel-summary-lines",
							children: [selectedBagelSummary.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { children: item.quantity }), item.name] }, item.name)), bagelTotal < bagelTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "pending",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { children: bagelTarget - bagelTotal }), "por elegir"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: bagelTotal === bagelTarget ? "Listo para continuar" : category === "packs" && packMix === "single" ? "Toca un solo sabor para todo tu pack" : "Toca los sabores en la vitrina" })
					]
				}),
				bagelTotal === bagelTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "guided-primary-next",
					onClick: nextFromBagels,
					children: ["Continuar ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "→" })]
				})
			] }),
			scene === "schmears" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mobile-product-stage mobile-schmear-stage",
					"aria-label": "Selecciona sabores de schmears",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
							"ESTACIÓN DE SCHMEARS · ",
							schmearSize,
							" G"
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: referenceMode && category === "packs" ? "¿Agregamos un schmear?" : "Elige tu schmear" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: category === "packs" ? referenceMode ? "Opcional · 120 g · toca de nuevo para quitar" : "Opcional · toca de nuevo para quitar" : schmearTotal + " de " + schmearTarget + " seleccionados" })
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mobile-schmear-grid",
						onFocusCapture: directCatalog ? revealFocusedCatalogCard : void 0,
						children: menu.schmears.map((item, index) => {
							const count = schmearCounts[item.id] ?? 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "mobile-schmear-card",
								"data-selected": count > 0,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => addSchmear(item.id),
									"aria-label": "Agregar " + item.name,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mobile-schmear-pot",
											style: {
												backgroundImage: "url(\"" + sceneImage + "\")",
												backgroundPosition: index * 25 + "% center"
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mobile-schmear-label",
											children: item.name
										}),
										item.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: item.note }),
										referenceMode && category === "packs" && optionalPackSchmearSize && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
											className: "reference-schmear-price",
											children: ["120 g · S/", item.price_class === "original" ? optionalPackSchmearSize.original_price : optionalPackSchmearSize.flavoured_price]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											"aria-hidden": "true",
											children: count ? "✓" : "+"
										})
									]
								}), count > 0 && category === "combos" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mobile-product-count",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => removeSchmear(item.id),
										"aria-label": "Quitar " + item.name,
										children: "−"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: count })]
								})]
							}, item.id);
						})
					})]
				}),
				!directCatalog && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "guided-product-frame schmear-product-frame",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: sceneImage,
						alt: "Estación de schmears"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "guided-product-hotspots schmear-hotspots",
						children: menu.schmears.map((item, index) => {
							const count = schmearCounts[item.id] ?? 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								style: SCHMEAR_SPOTS[index],
								"data-selected": count > 0,
								onClick: () => addSchmear(item.id),
								"aria-label": "Agregar " + item.name,
								children: [count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: count }), count > 0 && category === "combos" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
									role: "button",
									onClick: (e) => {
										e.stopPropagation();
										removeSchmear(item.id);
									},
									children: "−"
								})]
							}, item.id);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "guided-order-counter",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
							"SCHMEARS · ",
							schmearSize,
							" g"
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: category === "combos" ? schmearTotal + "/" + schmearTarget : schmearTotal ? "✓" : "0/1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: category === "packs" ? "Opcional · toca para añadir o quitar" : "Elige directamente de la estación" })
					]
				}),
				(category === "packs" || schmearTotal === schmearTarget) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "guided-primary-next",
					onClick: nextFromSchmears,
					children: [
						category === "schmears" ? "Continuar" : referenceMode && category === "packs" && schmearTotal === 0 ? "Ir a caja sin schmear" : "Ir a caja",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "→" })
					]
				})
			] }),
			!referenceMode && !reviewOnly && scene === "cross-sell" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrossSellPanel, {
				onPrimary: acceptPrimaryUpsell,
				onDownsell: acceptDownsell,
				onSkip: () => setScene("cashier")
			}),
			scene === "cashier" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "guided-cashier-action",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "guided-cashier-copy",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "CAJA BAGELITO" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Tu pedido" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "guided-cashier-lines",
								children: [selectedBagelSummary.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("i", { children: [item.quantity, " ×"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: item.name })] }, item.name)), selectedSchmearSummary.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("i", { children: [item.quantity, " ×"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [item.name, category === "schmears" ? " · " + schmearSize + " g" : ""] })] }, item.name))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "guided-cashier-quote",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: paymentConfig?.enabled !== true ? "Precio final por confirmar" : quoteLoading ? "Validando precio e inventario…" : checkoutQuote?.checkoutAllowed ? "Subtotal verificado" : "Necesita revisión" }), paymentConfig?.enabled === true && checkoutQuote?.amountPen != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: ["S/ ", checkoutQuote.amountPen] })]
							}),
							reviewOnly ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Revisa tu selección, los datos de entrega y el consentimiento. Esta vista no envía pedidos ni realiza pagos." }) : paymentConfig?.enabled !== true ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Tu selección está lista para consultar. Bagelito confirmará el precio y la fecha de entrega por WhatsApp." }) : !quoteLoading && checkoutQuote?.reasons?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: checkoutQuote.reasons[0] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El delivery se calcula con tu dirección antes de crear la reserva." })
						]
					}),
					(reviewOnly || canPayOnline || qaMode) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: quoteLoading && !qaMode,
						onClick: () => {
							if (reviewOnly || canPayOnline || qaMode) setScene("pay");
						},
						children: [
							reviewOnly ? "Revisar entrega y consentimiento" : qaMode && !canPayOnline ? "Continuar QA" : "Pagar online de forma segura",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "→" })
						]
					}),
					!reviewOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "guided-launch-contact",
						children: [manualOrderHref && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							className: canPayOnline ? "is-secondary" : "is-primary",
							href: manualOrderHref,
							target: "_blank",
							rel: "noopener noreferrer",
							children: [canPayOnline ? "Consultar por WhatsApp" : "Consultar mi pedido por WhatsApp", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								"aria-hidden": "true",
								children: "↗"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: canPayOnline ? "Consulta adicional, sin modificar tu pedido." : "Confirma disponibilidad, precio y fecha con Bagelito. Sin pago ni reserva automática." })]
					})
				]
			}),
			scene === "pay" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "guided-payment-gate",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "guided-payment-sheet",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "guided-payment-copy",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: reviewOnly ? "REVISIÓN DE ENTREGA" : "PAGO SEGURO" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Completa tu delivery" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: reviewOnly ? "Puedes revisar tus datos y el consentimiento. El pago no está activo en esta vista." : paymentConfig?.enabled ? "El total final se valida en servidor antes de abrir Culqi." : paymentConfig?.configured && paymentConfig?.bridgeReady && paymentConfig?.webhookReady && !paymentConfig?.clientReady ? "El checkout del navegador está en validación final." : paymentConfig?.configured && paymentConfig?.bridgeReady && !paymentConfig?.webhookReady ? "El checkout permanece cerrado hasta terminar webhook y reconciliación." : paymentConfig?.configured ? "Culqi está configurado, pero el bridge transaccional sigue cerrado." : "El pedido solo avanza cuando el servidor confirme el cobro." })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "checkout-customer-grid",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Nombre" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: checkoutCustomer.customerName,
									onChange: (e) => setCheckoutCustomer((v) => ({
										...v,
										customerName: e.target.value
									})),
									autoComplete: "name"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "email",
									value: checkoutCustomer.email,
									onChange: (e) => setCheckoutCustomer((v) => ({
										...v,
										email: e.target.value
									})),
									autoComplete: "email"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "WhatsApp" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									inputMode: "tel",
									value: checkoutCustomer.whatsapp,
									onChange: (e) => setCheckoutCustomer((v) => ({
										...v,
										whatsapp: e.target.value
									})),
									autoComplete: "tel"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Distrito" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: checkoutCustomer.district,
									onChange: (e) => setCheckoutCustomer((v) => ({
										...v,
										district: e.target.value
									})),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Elige distrito"
									}), deliveryDistricts.map((district) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: district,
										children: district
									}, district))]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "wide",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Dirección de delivery" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: checkoutCustomer.deliveryAddress,
										onChange: (e) => setCheckoutCustomer((v) => ({
											...v,
											deliveryAddress: e.target.value
										})),
										autoComplete: "street-address"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Referencia" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: checkoutCustomer.addressReference,
									onChange: (e) => setCheckoutCustomer((v) => ({
										...v,
										addressReference: e.target.value
									}))
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Notas" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: checkoutCustomer.deliveryNotes,
									onChange: (e) => setCheckoutCustomer((v) => ({
										...v,
										deliveryNotes: e.target.value
									}))
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "checkout-terms-check",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: checkoutCustomer.termsAccepted,
								onChange: (e) => setCheckoutCustomer((v) => ({
									...v,
									termsAccepted: e.target.checked
								}))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Acepto los ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "/legal",
									target: "_blank",
									rel: "noreferrer",
									children: "términos vigentes"
								}),
								" del checkout y delivery."
							] })]
						}),
						paymentReviewMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "checkout-review-message",
							children: paymentReviewMessage
						}),
						!reviewOnly && paymentConfig && checkoutQuote?.amountPen != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CulqiBrowserCheckout, {
							config: paymentConfig,
							customer: checkoutCustomer,
							subtotalPen: checkoutQuote.amountPen,
							order: {
								category,
								packFormat,
								packQty,
								packMix,
								bagels: bagelCounts,
								schmears: schmearCounts,
								schmearSize,
								comboId,
								bagelMode
							},
							onReview: setPaymentReviewMessage,
							onPaid: ({ orderCode, amountPen }) => {
								setPaidOrderCode(orderCode);
								setPaidAmountPen(amountPen);
								setPaymentReviewMessage("");
								setScene("receipt");
							}
						}),
						reviewOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "reference-payment-review",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: true,
								children: "Pago no activo"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "status",
								children: "Modo revisión: no se envían datos, no se crea una reserva y no se realiza ningún cobro."
							})]
						}),
						qaMode && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "guided-pay-hotspot qa-only-pay",
							onClick: () => setScene("receipt"),
							"aria-label": "Continuar en modo QA",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Continuar QA →" })
						})
					]
				})
			}),
			!reviewOnly && scene === "receipt" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "live-receipt-sheet" + (receiptPulled ? " pulled" : ""),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "live-receipt-brand",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: qaMode ? "PREVIEW VISUAL · SIN COBRO" : "BAGELITO" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: paidOrderCode ?? (qaMode ? "QA PREVIEW" : "PEDIDO CONFIRMADO") })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "live-receipt-lines",
						children: [selectedBagelSummary.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("i", { children: [item.quantity, " ×"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: item.name })] }, "receipt-" + item.name)), selectedSchmearSummary.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("i", { children: [item.quantity, " ×"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: item.name })] }, "receipt-" + item.name))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "live-receipt-total",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "TOTAL" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: paidAmountPen != null ? "S/ " + paidAmountPen.toFixed(2) : qaMode ? "Validado al pagar" : "Confirmado" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: qaMode ? "Este recibo es solo una vista de QA." : "Gracias por tu compra." })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "receipt-interaction" + (receiptPulled ? " pulled" : ""),
				role: "button",
				tabIndex: 0,
				"aria-label": "Jalar o tocar para retirar tu recibo",
				onPointerDown: (e) => {
					receiptDrag.current.startY = e.clientY;
					receiptDrag.current.offset = 0;
					e.currentTarget.setPointerCapture(e.pointerId);
				},
				onPointerMove: (e) => {
					if (!receiptDrag.current.startY) return;
					receiptDrag.current.offset = Math.max(0, e.clientY - receiptDrag.current.startY);
					if (receiptDrag.current.offset > 80) pullReceipt();
				},
				onPointerUp: (e) => {
					if (receiptDrag.current.offset > 60) pullReceipt();
					receiptDrag.current.startY = 0;
					receiptDrag.current.offset = 0;
					if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
				},
				onPointerCancel: () => {
					receiptDrag.current.startY = 0;
					receiptDrag.current.offset = 0;
				},
				onClick: pullReceipt,
				onKeyDown: (e) => {
					if (e.key === "Enter" || e.key === " ") {
						e.preventDefault();
						pullReceipt();
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Jala tu recibo ↓" })
			})] }),
			!referenceMode && !reviewOnly && scene === "wallet" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "wallet-screen-live",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: qaMode ? "PREVIEW VISUAL" : "BAGELITO CLUB" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Bagelito Club" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: qaMode ? "Sin puntos ni saldo ficticio · no genera un pass real." : "Tu tarjeta digital aparecerá aquí cuando Wallet esté habilitado." })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "wallet-actions",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "wallet-copy",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "BAGELITO CLUB" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: qaMode ? "Así se verá tu tarjeta" : "Tu tarjeta Bagelito Club" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: qaMode ? "Preview de interacción. No se guarda ningún pass." : "La integración con Wallet todavía no está habilitada." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "wallet-primary",
						disabled: !qaMode,
						onClick: () => {
							if (qaMode) saveWallet();
						},
						children: walletSaved ? "Preview completado ✓" : qaMode ? "Preview Apple Wallet" : "Apple Wallet · en integración"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "wallet-secondary",
						disabled: !qaMode,
						onClick: () => {
							if (qaMode) saveWallet();
						},
						children: qaMode ? "Preview Google Wallet" : "Google Wallet · en integración"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "wallet-skip",
						onClick: () => setScene("handoff"),
						children: "Ahora no"
					})
				]
			})] }),
			!reviewOnly && scene === "handoff" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "handoff-actions",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: qaMode ? "LISTO PARA TI" : "PEDIDO CONFIRMADO" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: qaMode ? "Tu Bagelito está listo." : "Ya recibimos tu pedido." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: qaMode ? "Toca para recibir la bolsa." : "Lo prepararemos para el delivery del batch confirmado." })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "handoff-action",
					onClick: () => setScene("goodbye"),
					children: [
						qaMode ? "Recibir pedido" : "Continuar",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "→" })
					]
				})]
			}),
			!reviewOnly && scene === "goodbye" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "goodbye-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "BAGELITO" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Nos vemos pronto." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: qaMode ? "Fin del recorrido visual de QA." : "Tu pedido quedó registrado. Te avisaremos según el batch confirmado." })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "goodbye-actions",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onExit,
						children: "Salir de Bagelito"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setScene("returning"),
						children: "Seguir explorando"
					})]
				})]
			}),
			!reviewOnly && scene === "returning" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "guided-returning-action",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "CLIENTE RECURRENTE" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Ya conoces el camino." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El local sigue vivo alrededor de ti mientras vuelves a pedir." })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => {
						setScene("selector");
						setCategory(null);
						resetSelections();
						setReceiptPulled(false);
						receiptPulledRef.current = false;
						setWalletSaved(false);
						setPaidOrderCode(null);
						setPaidAmountPen(null);
					},
					children: ["Volver al tótem ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "→" })]
				})]
			})
		]
	});
}
function CrossSellPanel({ onPrimary, onDownsell, onSkip }) {
	const [showDownsell, setShowDownsell] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "cross-sell-actions",
		children: !showDownsell ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "primary",
			onClick: onPrimary,
			children: "Sí, quiero 8 🥯"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => setShowDownsell(true),
			children: "Solo el schmear"
		})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "primary",
			onClick: onDownsell,
			children: "Sí, agregar 2"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: onSkip,
			children: "No, gracias"
		})] })
	});
}
function ReferenceStorefront() {
	const [scene, setScene] = (0, import_react.useState)("selector");
	(0, import_react.useEffect)(() => {
		const frame = requestAnimationFrame(() => {
			if (scene === "selector" || scene === "entrance") {
				window.scrollTo({
					top: 0,
					behavior: "auto"
				});
				return;
			}
			document.querySelector(".reference-mode .guided-floating-panel,.reference-mode .mobile-product-stage,.reference-mode .approved-combo-overlay,.reference-mode .guided-cashier-action,.reference-mode .guided-payment-gate")?.scrollIntoView({
				block: "start",
				behavior: "auto"
			});
		});
		return () => cancelAnimationFrame(frame);
	}, [scene]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "reference-storefront",
		"data-review-only": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuidedCommerce, {
				referenceMode: true,
				reviewOnly: true,
				skipEntrance: true,
				exitLabel: "Volver a la vitrina",
				onExit: () => window.location.assign("/"),
				onSceneChange: setScene
			}),
			scene === "pay" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "reference-loyalty",
				"aria-label": "Programa de fidelidad",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "FIDELIDAD BAGELITO" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Cada 10 pedidos, 2 bagels + 1 schmear gratis." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "El programa usará pedidos verificados y seguimiento interno. El registro y el canje están pendientes de implementación; esta revisión no genera pedidos ni recompensas." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "reference-review-note",
				children: "Vista de revisión · sin cobros, reservas ni envío de datos. Los precios dibujados pertenecen a la imagen de referencia; las opciones del flujo usan el catálogo verificado."
			})
		]
	});
}
export { ReferenceStorefront };
