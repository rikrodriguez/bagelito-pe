import { ReferenceStorefront } from "./ReferenceStorefront-C5kQbN0Z.mjs";
import { require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/routes-C0mOgfVU.js
var import_jsx_runtime = require_jsx_runtime();
function StoreEntry() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReferenceStorefront, {});
}
export { StoreEntry as component };
