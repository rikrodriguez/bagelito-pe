globalThis.__nitro_main__ = import.meta.url;
import { H3Core, HTTPError, NodeResponse, composeMiddleware, createMatcherFromFind, defineHandler, defineLazyEventHandler, headers, memoizeRouteRulesMatcher, serve, toEventHandler } from "./_libs/h3+rou3+srvx.mjs";
import { HookableCore } from "./_libs/hookable.mjs";
import { decodePath, joinURL, withLeadingSlash, withoutTrailingSlash } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
// #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/bagel-vitrina.webp": {
		"type": "image/webp",
		"etag": "\"5e2-tpo4iwOS6BizB4mACBOoD8PwzOc\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 1506,
		"path": "../public/bagel-vitrina.webp"
	},
	"/bagelito-counter.webp": {
		"type": "image/webp",
		"etag": "\"5e2-5lMzNEgGSgQoLgwOlgXf+phYVC0\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 1506,
		"path": "../public/bagelito-counter.webp"
	},
	"/schmear-vitrina.webp": {
		"type": "image/webp",
		"etag": "\"5e2-0yVY7t5tioIvyVGkcMtkcagCx2Y\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 1506,
		"path": "../public/schmear-vitrina.webp"
	},
	"/store-category-flow.webp": {
		"type": "image/webp",
		"etag": "\"21fc-1zt26B+lr1xzWJszRX7pY9YTzNQ\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 8700,
		"path": "../public/store-category-flow.webp"
	},
	"/store-entry-door.webp": {
		"type": "image/webp",
		"etag": "\"2a52-ysiyoaxdWitXhD0cZqAcDF+sSLE\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 10834,
		"path": "../public/store-entry-door.webp"
	},
	"/assets/ReferenceStorefront-BMQQ7NiK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ea9a-VnHoW64Uk19zD3I5Rq4e+7j6d1g\"",
		"mtime": "2026-11-01T00:35:00.787Z",
		"size": 60058,
		"path": "../public/assets/ReferenceStorefront-BMQQ7NiK.js"
	},
	"/assets/ReferenceStorefront-CF3L9wuz.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"18490-+2rmebG1BVk1/SMYGgd/bj/AWWQ\"",
		"mtime": "2026-11-01T00:35:00.787Z",
		"size": 99472,
		"path": "../public/assets/ReferenceStorefront-CF3L9wuz.css"
	},
	"/assets/index-B-tAIt2X.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"64a-ob5cV86axjCdufrJdMGH+CUZEBs\"",
		"mtime": "2026-11-01T00:35:00.787Z",
		"size": 1610,
		"path": "../public/assets/index-B-tAIt2X.css"
	},
	"/assets/index-aRb2m3Gb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"537c3-okUVh/IDQ1c9gWYiXcbmCFot4Ck\"",
		"mtime": "2026-11-01T00:35:00.781Z",
		"size": 341955,
		"path": "../public/assets/index-aRb2m3Gb.js"
	},
	"/assets/legal-a6igGOl0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11f1-n5sOo2GkGZwxhJxTxN2nHjRYSBs\"",
		"mtime": "2026-11-01T00:35:00.787Z",
		"size": 4593,
		"path": "../public/assets/legal-a6igGOl0.js"
	},
	"/assets/legal-version-BguVS3S4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22-nsDx80M5GuExWPd8a/jWM6xyuSQ\"",
		"mtime": "2026-11-01T00:35:00.787Z",
		"size": 34,
		"path": "../public/assets/legal-version-BguVS3S4.js"
	},
	"/assets/playable-BSbH2qWw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2-7/mcdSgAk3eohD0WsfcTkwlw2IE\"",
		"mtime": "2026-11-01T00:35:00.787Z",
		"size": 162,
		"path": "../public/assets/playable-BSbH2qWw.js"
	},
	"/assets/routes-BSbH2qWw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2-7/mcdSgAk3eohD0WsfcTkwlw2IE\"",
		"mtime": "2026-11-01T00:35:00.787Z",
		"size": 162,
		"path": "../public/assets/routes-BSbH2qWw.js"
	},
	"/images/bagel-blueberry.webp": {
		"type": "image/webp",
		"etag": "\"103fe-lQqbezoAi/pAkXR/O0oYG4D9kS4\"",
		"mtime": "2026-11-01T00:35:01.024Z",
		"size": 66558,
		"path": "../public/images/bagel-blueberry.webp"
	},
	"/images/bagel-cheddar.webp": {
		"type": "image/webp",
		"etag": "\"10600-KUPamcqOkxR1oR9OSzvKT/NAkLw\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 67072,
		"path": "../public/images/bagel-cheddar.webp"
	},
	"/images/bagel-cinnamon-raisin.webp": {
		"type": "image/webp",
		"etag": "\"10a96-L6rup0CXVgd7uwrAWrn6AJ4DrMw\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 68246,
		"path": "../public/images/bagel-cinnamon-raisin.webp"
	},
	"/images/bagel-classic-onion.webp": {
		"type": "image/webp",
		"etag": "\"1126e-wCIAzkz+gViUjCMa98bU1Z5/v+M\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 70254,
		"path": "../public/images/bagel-classic-onion.webp"
	},
	"/images/bagel-everything.webp": {
		"type": "image/webp",
		"etag": "\"13658-DJUKhc+y4nfWXKO4CdpOTVjj3kM\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 79448,
		"path": "../public/images/bagel-everything.webp"
	},
	"/images/bagel-jalapeno-cheddar.webp": {
		"type": "image/webp",
		"etag": "\"10808-hfh+r9vxlPVwJqIutEyulzH9CjY\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 67592,
		"path": "../public/images/bagel-jalapeno-cheddar.webp"
	},
	"/images/bagel-plain.webp": {
		"type": "image/webp",
		"etag": "\"f1ce-Ai4aQ1nC5zkVWd+CnhRF5+FYdt0\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 61902,
		"path": "../public/images/bagel-plain.webp"
	},
	"/images/bagel-sesame.webp": {
		"type": "image/webp",
		"etag": "\"1d30c-NOvwIe9BGZf7elSHZqRu6Y+LTf4\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 119564,
		"path": "../public/images/bagel-sesame.webp"
	},
	"/images/bagel-vitrina-photo.webp": {
		"type": "image/webp",
		"etag": "\"15152-vppwTwZRSoSVxLjZ/JDR/uhJ+Vo\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 86354,
		"path": "../public/images/bagel-vitrina-photo.webp"
	},
	"/images/bagelito-logo.svg": {
		"type": "image/svg+xml",
		"etag": "\"1c6-F8R2bEST8HaEd9dNJBBHoJPHqMA\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 454,
		"path": "../public/images/bagelito-logo.svg"
	},
	"/images/bagelito-wordmark.svg": {
		"type": "image/svg+xml",
		"etag": "\"1ff-CXoog25QrQ5rfXA7jLHQP3Pobyg\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 511,
		"path": "../public/images/bagelito-wordmark.svg"
	},
	"/images/guided-storyboard-atlas-2.webp": {
		"type": "image/webp",
		"etag": "\"61ac0-cTA7SYznteyxN6NKxkBx6RdBT9k\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 400064,
		"path": "../public/images/guided-storyboard-atlas-2.webp"
	},
	"/images/pack-6-mixed.webp": {
		"type": "image/webp",
		"etag": "\"12e74-IYZEZ6bWOmzFAIkRZZK1fXA6sBw\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 77428,
		"path": "../public/images/pack-6-mixed.webp"
	},
	"/images/schmear-vitrina-photo.webp": {
		"type": "image/webp",
		"etag": "\"a000-EyuL0KvCCOzVP5tFAMOFBS47VJw\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 40960,
		"path": "../public/images/schmear-vitrina-photo.webp"
	},
	"/images/guided-storyboard-atlas.webp": {
		"type": "image/webp",
		"etag": "\"68adc-+ItBBZtjQfDLHpG/Ef1b64vwY+4\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 428764,
		"path": "../public/images/guided-storyboard-atlas.webp"
	},
	"/images/store-reference-approved.webp": {
		"type": "image/webp",
		"etag": "\"504be-7bMIW5WjHG5dyF8Y6J6eGdlt/+g\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 328894,
		"path": "../public/images/store-reference-approved.webp"
	},
	"/master-scenes/bag-handoff.webp": {
		"type": "image/webp",
		"etag": "\"19992-JlV7A070KPxsCrsKTkmcHgbgDu4\"",
		"mtime": "2026-11-01T00:35:01.024Z",
		"size": 104850,
		"path": "../public/master-scenes/bag-handoff.webp"
	},
	"/master-scenes/cashier.webp": {
		"type": "image/webp",
		"etag": "\"16502-QLQoTHD8O//wFcSj9io2jleteJ0\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 91394,
		"path": "../public/master-scenes/cashier.webp"
	},
	"/master-scenes/bagels-vitrina.webp": {
		"type": "image/webp",
		"etag": "\"2de3a-RMlzSu+yO2QHg5HxRhQIhQZHqfk\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 187962,
		"path": "../public/master-scenes/bagels-vitrina.webp"
	},
	"/master-scenes/combos.webp": {
		"type": "image/webp",
		"etag": "\"15fea-6JpfGKRWgwVBADVj9oXxvPDOdYM\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 90090,
		"path": "../public/master-scenes/combos.webp"
	},
	"/master-scenes/cross-sell.webp": {
		"type": "image/webp",
		"etag": "\"14c12-QJuabqKPBnfs+5qGcsi3vwC/1/4\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 85010,
		"path": "../public/master-scenes/cross-sell.webp"
	},
	"/master-scenes/goodbye.webp": {
		"type": "image/webp",
		"etag": "\"1f84e-zhdI6/iAS3iUXn7RDMd7som6yO0\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 129102,
		"path": "../public/master-scenes/goodbye.webp"
	},
	"/master-scenes/entrance.webp": {
		"type": "image/webp",
		"etag": "\"2eef4-zdokphbP1ZCEs9HqYRv8E03IQv8\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 192244,
		"path": "../public/master-scenes/entrance.webp"
	},
	"/master-scenes/inside.webp": {
		"type": "image/webp",
		"etag": "\"26e10-LJAAJXQKkC3gH1E+tfAuAQbTpWQ\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 159248,
		"path": "../public/master-scenes/inside.webp"
	},
	"/master-scenes/packs.webp": {
		"type": "image/webp",
		"etag": "\"16c6a-7+Wa3UtG79V/UfQs6A3znZlocwM\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 93290,
		"path": "../public/master-scenes/packs.webp"
	},
	"/master-scenes/pay.webp": {
		"type": "image/webp",
		"etag": "\"170f2-pfoJFr/J4oLSZzRdPa3t2qixrWc\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 94450,
		"path": "../public/master-scenes/pay.webp"
	},
	"/master-scenes/receipt.webp": {
		"type": "image/webp",
		"etag": "\"15f86-EjBv7HBMB6HuTO5S5DKBC6Kk2BM\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 89990,
		"path": "../public/master-scenes/receipt.webp"
	},
	"/master-scenes/schmears.webp": {
		"type": "image/webp",
		"etag": "\"1c374-mpTZQptL/1EWoLy3FfXLrVRgwzU\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 115572,
		"path": "../public/master-scenes/schmears.webp"
	},
	"/master-scenes/schmears-vitrina.webp": {
		"type": "image/webp",
		"etag": "\"26378-5F63YYnSMYKHWy/WZYtz2ELmuyg\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 156536,
		"path": "../public/master-scenes/schmears-vitrina.webp"
	},
	"/master-scenes/wallet.webp": {
		"type": "image/webp",
		"etag": "\"14a8a-+xgPPjd54lvgwoCM9HGOrRLokfQ\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 84618,
		"path": "../public/master-scenes/wallet.webp"
	},
	"/master-scenes/selector.webp": {
		"type": "image/webp",
		"etag": "\"2c3c2-nSqdIXbSD/BvFpx4odvoV2bTgF4\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 181186,
		"path": "../public/master-scenes/selector.webp"
	},
	"/master-scenes-clean/bag-handoff.webp": {
		"type": "image/webp",
		"etag": "\"1a35a-Pimb0x2HUNT+vOI91JJ0kNTTSCc\"",
		"mtime": "2026-11-01T00:35:01.024Z",
		"size": 107354,
		"path": "../public/master-scenes-clean/bag-handoff.webp"
	},
	"/master-scenes-clean/cashier.webp": {
		"type": "image/webp",
		"etag": "\"1587a-+D2HEQ6S3D5+ZWla4dYh5qiQQG4\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 88186,
		"path": "../public/master-scenes-clean/cashier.webp"
	},
	"/master-scenes-clean/bagels-vitrina.webp": {
		"type": "image/webp",
		"etag": "\"2dbc4-RttXIkGHBuQbJbuBN+wSb2VLrlQ\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 187332,
		"path": "../public/master-scenes-clean/bagels-vitrina.webp"
	},
	"/master-scenes-clean/combos.webp": {
		"type": "image/webp",
		"etag": "\"17b58-PzMgrqlXXl3fs/qWpoi2G1nl76A\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 97112,
		"path": "../public/master-scenes-clean/combos.webp"
	},
	"/master-scenes-clean/cross-sell.webp": {
		"type": "image/webp",
		"etag": "\"15e5e-4dhp7KRy5boI70KSQ8Wa8aKfPq4\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 89694,
		"path": "../public/master-scenes-clean/cross-sell.webp"
	},
	"/master-scenes-clean/entrance.webp": {
		"type": "image/webp",
		"etag": "\"318b2-eiRyC+VO6Eb8dGM8hs2lg1nYUFM\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 202930,
		"path": "../public/master-scenes-clean/entrance.webp"
	},
	"/master-scenes-clean/goodbye.webp": {
		"type": "image/webp",
		"etag": "\"22116-PTYxbzdUTRcmp+0d8PURDWh4uAc\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 139542,
		"path": "../public/master-scenes-clean/goodbye.webp"
	},
	"/master-scenes-clean/inside.webp": {
		"type": "image/webp",
		"etag": "\"2b0fa-RSTea12rejtI7jXft5YxAlWvUvI\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 176378,
		"path": "../public/master-scenes-clean/inside.webp"
	},
	"/master-scenes-clean/packs.webp": {
		"type": "image/webp",
		"etag": "\"1899a-wyCnSW6qohMELJtcSBB+OXeJFFw\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 100762,
		"path": "../public/master-scenes-clean/packs.webp"
	},
	"/master-scenes-clean/pay.webp": {
		"type": "image/webp",
		"etag": "\"18636-W1Lb+BWdZycZ9lqRpRGNYhjXe5o\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 99894,
		"path": "../public/master-scenes-clean/pay.webp"
	},
	"/master-scenes-clean/receipt.webp": {
		"type": "image/webp",
		"etag": "\"16d28-Y8XtHRVTNVvyN4nRTBFjh6059tw\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 93480,
		"path": "../public/master-scenes-clean/receipt.webp"
	},
	"/master-scenes-clean/schmears-vitrina.webp": {
		"type": "image/webp",
		"etag": "\"16800-/gDworCWwgQt0Xddi9tX8Tm25vA\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 92160,
		"path": "../public/master-scenes-clean/schmears-vitrina.webp"
	},
	"/master-scenes-clean/schmears.webp": {
		"type": "image/webp",
		"etag": "\"1f38a-S4tCh1QwFiPBDAMyZyLMTYLiqbA\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 127882,
		"path": "../public/master-scenes-clean/schmears.webp"
	},
	"/master-scenes-clean/selector.webp": {
		"type": "image/webp",
		"etag": "\"32d1a-8KPbZ4VYf/4XDwPEuPB2GvFQl6k\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 208154,
		"path": "../public/master-scenes-clean/selector.webp"
	},
	"/master-scenes-clean/wallet.webp": {
		"type": "image/webp",
		"etag": "\"13ab2-eNHm2ix4EsJv3jZSyw6McQ8RB2M\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 80562,
		"path": "../public/master-scenes-clean/wallet.webp"
	},
	"/models/bagel-everything-512.glb": {
		"type": "model/gltf-binary",
		"etag": "\"5e2-h0UANX8amw4Xy5SlxgektHiKdeQ\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 1506,
		"path": "../public/models/bagel-everything-512.glb"
	},
	"/models/bagel-everything-1024.glb": {
		"type": "model/gltf-binary",
		"etag": "\"5e2-YiQu8rjs1wf6+RVU/DBDWgHIjUk\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 1506,
		"path": "../public/models/bagel-everything-1024.glb"
	},
	"/reference/storyboard-master.webp": {
		"type": "image/webp",
		"etag": "\"42d9a-c1B4dHWSDqm3/sallK7Ts8/9S0w\"",
		"mtime": "2026-11-01T00:35:01.026Z",
		"size": 273818,
		"path": "../public/reference/storyboard-master.webp"
	},
	"/reference/storyboard-main.webp": {
		"type": "image/webp",
		"etag": "\"39026-jhhp/SWxLMOzH+LRdtg1eTDwXdE\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 233510,
		"path": "../public/reference/storyboard-main.webp"
	},
	"/reference/storyboard-schmears.webp": {
		"type": "image/webp",
		"etag": "\"3cd36-B/KxTNhXeFYjCC5+TVmZU8pdN58\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 249142,
		"path": "../public/reference/storyboard-schmears.webp"
	},
	"/scenes/bag-handoff.webp": {
		"type": "image/webp",
		"etag": "\"19992-JlV7A070KPxsCrsKTkmcHgbgDu4\"",
		"mtime": "2026-11-01T00:35:01.025Z",
		"size": 104850,
		"path": "../public/scenes/bag-handoff.webp"
	},
	"/scenes/combos.webp": {
		"type": "image/webp",
		"etag": "\"15fea-6JpfGKRWgwVBADVj9oXxvPDOdYM\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 90090,
		"path": "../public/scenes/combos.webp"
	},
	"/scenes/cross-sell.webp": {
		"type": "image/webp",
		"etag": "\"14c12-QJuabqKPBnfs+5qGcsi3vwC/1/4\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 85010,
		"path": "../public/scenes/cross-sell.webp"
	},
	"/scenes/cashier.webp": {
		"type": "image/webp",
		"etag": "\"16502-QLQoTHD8O//wFcSj9io2jleteJ0\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 91394,
		"path": "../public/scenes/cashier.webp"
	},
	"/scenes/bagels-vitrina.webp": {
		"type": "image/webp",
		"etag": "\"2de3a-RMlzSu+yO2QHg5HxRhQIhQZHqfk\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 187962,
		"path": "../public/scenes/bagels-vitrina.webp"
	},
	"/scenes/goodbye.webp": {
		"type": "image/webp",
		"etag": "\"1f84e-zhdI6/iAS3iUXn7RDMd7som6yO0\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 129102,
		"path": "../public/scenes/goodbye.webp"
	},
	"/scenes/inside.webp": {
		"type": "image/webp",
		"etag": "\"26e10-LJAAJXQKkC3gH1E+tfAuAQbTpWQ\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 159248,
		"path": "../public/scenes/inside.webp"
	},
	"/scenes/entrance.webp": {
		"type": "image/webp",
		"etag": "\"2eef4-zdokphbP1ZCEs9HqYRv8E03IQv8\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 192244,
		"path": "../public/scenes/entrance.webp"
	},
	"/scenes/packs.webp": {
		"type": "image/webp",
		"etag": "\"16c6a-7+Wa3UtG79V/UfQs6A3znZlocwM\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 93290,
		"path": "../public/scenes/packs.webp"
	},
	"/scenes/pay.webp": {
		"type": "image/webp",
		"etag": "\"170f2-pfoJFr/J4oLSZzRdPa3t2qixrWc\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 94450,
		"path": "../public/scenes/pay.webp"
	},
	"/scenes/receipt.webp": {
		"type": "image/webp",
		"etag": "\"15f86-EjBv7HBMB6HuTO5S5DKBC6Kk2BM\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 89990,
		"path": "../public/scenes/receipt.webp"
	},
	"/scenes/schmears-vitrina.webp": {
		"type": "image/webp",
		"etag": "\"26378-5F63YYnSMYKHWy/WZYtz2ELmuyg\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 156536,
		"path": "../public/scenes/schmears-vitrina.webp"
	},
	"/scenes/schmears.webp": {
		"type": "image/webp",
		"etag": "\"1c374-mpTZQptL/1EWoLy3FfXLrVRgwzU\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 115572,
		"path": "../public/scenes/schmears.webp"
	},
	"/scenes/wallet.webp": {
		"type": "image/webp",
		"etag": "\"14a8a-+xgPPjd54lvgwoCM9HGOrRLokfQ\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 84618,
		"path": "../public/scenes/wallet.webp"
	},
	"/scenes/selector.webp": {
		"type": "image/webp",
		"etag": "\"2c3c2-nSqdIXbSD/BvFpx4odvoV2bTgF4\"",
		"mtime": "2026-11-01T00:35:01.027Z",
		"size": 181186,
		"path": "../public/scenes/selector.webp"
	}
};
// #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
// #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
// node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
// src/server/reference-review-guard.server.ts
/** Runtime-only preview boundary; the financial handlers remain unchanged. */
function referenceReviewGuard(event) {
	if (process.env.BAGELITO_REFERENCE_REVIEW_ONLY !== "true") return;
	if (!/^\/+api(?:\/|$|%2f|%5c)/i.test(event.url.pathname)) return;
	return Response.json({
		ok: false,
		reviewOnly: true,
		error: "API disabled in image reference review."
	}, {
		status: 503,
		headers: {
			"Cache-Control": "private, no-store, max-age=0",
			"CDN-Cache-Control": "no-store",
			"X-Content-Type-Options": "nosniff"
		}
	});
}
// #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = {
		route: "/assets/**",
		rank: 0,
		rules: [{
			name: "headers",
			route: "/assets/**",
			handler: headers,
			options: { "cache-control": "public, max-age=31536000, immutable" }
		}]
	};
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1);
		let s = p.split("/");
		let l = s.length;
		let _w;
		if (l > 1) {
			if (s[1] === "assets") r.push(l > 2 ? {
				data: $0,
				params: {
					"0": _w = p.slice(8),
					_: _w
				}
			} : {
				data: $0,
				params: {}
			});
		}
		return r.reverse();
	};
})();
var _lazy_700d58d1e1da116e = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_700d58d1e1da116e
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default), toEventHandler(referenceReviewGuard)].filter(Boolean);
// node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
// #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
// #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => {
		event.context.routeRules = getRouteRules(event.req.method, event.url.pathname).routeRules;
		return findRoute(event.req.method, event.url.pathname);
	};
	h3App["~middleware"].push(createRouteRulesMiddleware());
	h3App["~middleware"].push(...globalMiddleware);
	return h3App;
}
// node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
var _matchRouteRules;
function getRouteRules(method, pathname) {
	return (_matchRouteRules ??= memoizeRouteRulesMatcher(createMatcherFromFind(findRouteRules)))(method, pathname);
}
function createRouteRulesMiddleware() {
	const composed = /* @__PURE__ */ new WeakMap();
	const middleware = (event, next) => {
		const ruleMiddleware = getRouteRules(event.req.method, event.url.pathname).routeRuleMiddleware;
		if (ruleMiddleware.length === 0) return next();
		let chain = composed.get(ruleMiddleware);
		if (!chain) {
			chain = composeMiddleware(ruleMiddleware);
			composed.set(ruleMiddleware, chain);
		}
		return chain(event, next);
	};
	return markUntraced(middleware);
}
function markUntraced(middleware) {
	middleware.__traced__ = true;
	return middleware;
}
// node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
// #nitro/virtual/tracing
var tracingSrvxPlugins = [];
// node_modules/nitro/dist/runtime/internal/shutdown.mjs
function setupCloseHooks(server) {
	const closeServer = server.close.bind(server);
	let closeHooks;
	server.close = (closeActiveConnections) => closeServer(closeActiveConnections).finally(() => closeHooks ??= callCloseHooks());
}
async function callCloseHooks() {
	try {
		await useNitroHooks().callHook("close");
	} catch (error) {
		console.error("[nitro] Error while calling `close` hooks:", error);
	}
}
// node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
setupCloseHooks(serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
}));
trapUnhandledErrors();
var node_server_default = {};
export { node_server_default as default };
