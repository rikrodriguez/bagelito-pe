await import('./server/index.mjs')
